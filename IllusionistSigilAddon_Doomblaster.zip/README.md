# IllusionistSigilAddon (Paper 1.21.1)

Plugin addon skill **Genesis Grip Sigil** yang terhubung ke **MMOItems**, **MythicLib**, **MythicMobs**, **ItemsAdder**, **MythicCrucible**, dan **ModelEngine**.

## Fitur
- **Klik Kanan Langsung Aktif**: Klik kanan sambil memegang kartu/senjata Illusionist (`MYSTICAL_CARD`, `MYSTICAL_CARD_SHINY`, `GENESIS_GRIP_SIGIL`, atau item namespace `illusionist:*`) langsung memulai chant & animasi Genesis Grip.
- **Third-Person Player Visible Camera**: Kamera sinematik menggunakan paket kamera (`ClientboundSetCameraPacket`) tanpa mengubah player ke mode Spectator, sehingga model karakter player, skin, armor, animasi tangan, serta kartu raksasa di atas kepala tetap terlihat penuh selama chant.
- **Auto Weapon Swap ke Doomblaster (Awakened Gunslinger)**: Tepat saat chant selesai masuk ke *Battle Mode*, add-on otomatis mencari **Doomblaster** (`AWAKENED_GUNSLINGER_DOOMBLASTER` / `awakened_gunslinger:awakened_gunslinger_doomblaster` / `CustomModelData: 2095`) di hotbar, offhand, maupun tas utama dan langsung menggantinya ke tangan utama lengkap dengan efek suara `spin_pistol`.
- **Overhead Card Display**: Kartu Illusionist melayang tinggi (`height-offset: 3.75`, `scale: 2.35`) dan berputar di atas kepala pemain.
