# IllusionistSigilAddon (Paper 1.21.1)

Plugin addon skill **Genesis Grip Sigil** yang terhubung ke **MMOItems**, **MythicLib**, **MythicMobs**, **ItemsAdder**, dan **ModelEngine**.

## Cara Build JAR di GitHub
1. Extract semua file dari ZIP ini ke root repository GitHub kamu (pastikan folder `.github/workflows/build.yml` ikut ter-upload).
2. Buka tab **Actions** di repository GitHub -> jalankan workflow **Build IllusionistSigilAddon Jar**.
3. Download artifact **`IllusionistSigilAddon-1.0.0`** lalu taruh `.jar` di dalamnya ke folder `plugins/` server Paper 1.21.1.

## Konfigurasi Server
Salin isi file di folder `server-configs/` ke masing-masing folder konfigurasi **MMOItems**, **MythicMobs**, dan **ItemsAdder**.
