# IllusionistSigilAddon (Paper 1.21.1)

Plugin addon skill **Genesis Grip Sigil** yang terhubung ke **MMOItems**, **MythicLib**, **MythicMobs**, **ItemsAdder**, dan **ModelEngine**.

## Fitur
- **Klik Kanan Langsung Aktif**: Klik kanan sambil memegang kartu/senjata Illusionist (`MYSTICAL_CARD`, `MYSTICAL_CARD_SHINY`, `GENESIS_GRIP_SIGIL`, atau item namespace `illusionist:*`) langsung memulai chant & animasi Genesis Grip tanpa perlu mengetik command.
- **Overhead Weapon Display**: Senjata/kartu Illusionist yang sedang dipegang melayang besar (`scale: 2.35`) dan berputar di atas kepala player.
- **Zero ArmorStand**: Kamera sinematik memakai `Interaction` entity (ukuran 0) sehingga tidak ada ArmorStand yang muncul.
