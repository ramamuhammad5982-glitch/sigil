# IllusionistSigilAddon (Paper 1.21.1)

Plugin addon skill **Solstice Muzzle Sigil** yang terhubung ke **MMOItems**, **MythicLib**, **MythicMobs**, **ItemsAdder**, **MythicCrucible**, dan **ModelEngine**.

## Fitur
- **Klik Kanan Langsung Aktif**: Klik kanan sambil memegang kartu/senjata Illusionist langsung memulai chant & animasi Solstice Muzzle.
- **Kompatibel dengan HUD Hotbar Custom**: Secara default tidak mengosongkan isi inventory/hotbar setelah chant (`post-chant-inventory.clear-inventory-after-chant: false`), cukup memindahkan slot aktif ke senjata/pistol agar HUD hotbar custom tetap utuh.
- **Kartu Hilang Setelah Chant**: Begitu chant selesai, tampilan kartu di atas kepala (`OverheadWeaponManager`) otomatis dihilangkan.
- **Klik Kanan Pistol untuk Nonaktifkan Chant Mode**: Saat mode pasca-chant aktif dan pemain memegang pistol (`Doomblaster` / `Desert Eagle` / senjata pistol), klik kanan pada pistol akan menonaktifkan chant mode dan mengembalikan slot ke kartu Illusionist.
- **Third-Person Player Visible Camera**: Kamera sinematik menggunakan paket kamera (`ClientboundSetCameraPacket`) tanpa mengubah player ke mode Spectator.
