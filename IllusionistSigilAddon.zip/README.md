# IllusionistSigilAddon (Paper 1.21.1)

Plugin addon skill **Genesis Grip Sigil** yang terhubung ke **MMOItems**, **MythicLib**, **MythicMobs**, **ItemsAdder**, dan **ModelEngine**.

## Fitur Terbaru
- **Pacu Chant dengan Klik Kanan Kartu/Sigil**: Saat fase Fast Chant berjalan, klik kanan pada Mystical Card atau Genesis Grip Sigil akan memacu bar progres chant lebih cepat.
- **Overhead Weapon Display**: Saat memegang senjata/kartu Illusionist di main hand, model item akan melayang besar (`scale: 2.35`) dan berputar di atas kepala player.
- **Zero ArmorStand**: Kamera sinematik menggunakan `Interaction` entity sehingga tidak ada bayangan ArmorStand yang terlihat saat mode Spectator aktif.
