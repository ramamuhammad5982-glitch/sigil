# IllusionistSigilAddon (Paper 1.21.1)

Plugin addon skill **Solstice Muzzle Sigil** yang terhubung ke **MMOItems**, **MythicLib**, **MythicMobs**, **ItemsAdder**, **MythicCrucible**, dan **ModelEngine**.

## Fitur
- **Klik Kanan Langsung Aktif**: Klik kanan sambil memegang kartu/senjata Illusionist langsung memulai chant & animasi Solstice Muzzle.
- **Summon Pistol Otomatis Walau Hanya Punya Sigil**: Jika pemain hanya membawa sigil/kartu tanpa pistol di inventory/hotbar/offhand, plugin otomatis memunculkan pistol (`MMOItems` / `ItemsAdder` / `MythicMobs` / custom item) setelah chant selesai sambil menjaga HUD hotbar custom tetap utuh (`clear-other-slots-on-summon: false`), lalu menghapus pistol summon dan mengembalikan sigil saat klik kanan pistol untuk menonaktifkan chant mode.
- **Kartu Hilang Setelah Chant**: Begitu chant selesai, tampilan kartu di atas kepala (`OverheadWeaponManager`) otomatis dihilangkan.
- **Klik Kanan Pistol untuk Nonaktifkan Chant Mode**: Saat mode pasca-chant aktif dan pemain memegang pistol (`Doomblaster` / `Desert Eagle` / senjata pistol), klik kanan pada pistol akan menonaktifkan chant mode.
- **Third-Person Player Visible Camera**: Kamera sinematik menggunakan paket kamera (`ClientboundSetCameraPacket`) tanpa mengubah player ke mode Spectator.
