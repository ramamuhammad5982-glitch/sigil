package id.wyn.illusionist.hook;

import id.wyn.illusionist.IllusionistSigilAddon;
import id.wyn.illusionist.core.GenesisGripExecutor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;

public class PluginBridgeManager implements Listener {

    private final IllusionistSigilAddon plugin;

    public PluginBridgeManager(IllusionistSigilAddon plugin) {
        this.plugin = plugin;
    }

    public String getActiveHooksSummary() {
        List<String> active = new ArrayList<>();
        for (String name : List.of("MythicLib", "MMOItems", "MythicMobs", "ItemsAdder", "ModelEngine")) {
            if (Bukkit.getPluginManager().isPluginEnabled(name)) {
                active.add(name);
            }
        }
        return active.isEmpty() ? "Standalone" : String.join(", ", active);
    }

    public boolean isGenesisGripSigil(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return false;

        String targetMmoId = plugin.getConfig().getString("hooks.mmoitems.sigil-id", "GENESIS_GRIP_SIGIL");
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        NamespacedKey mmoKey = new NamespacedKey("mmoitems", "mmoitems_item_id");
        if (pdc.has(mmoKey, PersistentDataType.STRING)) {
            String val = pdc.get(mmoKey, PersistentDataType.STRING);
            if (targetMmoId.equalsIgnoreCase(val)) return true;
        }

        if (Bukkit.getPluginManager().isPluginEnabled("ItemsAdder")) {
            try {
                Class<?> customStackClass = Class.forName("dev.lone.itemsadder.api.CustomStack");
                Object customStack = customStackClass.getMethod("byItemStack", ItemStack.class).invoke(null, item);
                if (customStack != null) {
                    String namespacedId = (String) customStackClass.getMethod("getNamespacedID").invoke(customStack);
                    String targetIaId = plugin.getConfig().getString("hooks.itemsadder.sigil-item", "illusionist:genesis_grip_sigil");
                    if (targetIaId.equalsIgnoreCase(namespacedId)) return true;
                }
            } catch (Exception ignored) {
            }
        }
        return false;
    }

    public double computeMythicLibMagicDamage(Player caster, double baseDamage) {
        if (!Bukkit.getPluginManager().isPluginEnabled("MythicLib")) return baseDamage;
        try {
            Class<?> mmoDataClass = Class.forName("io.lumine.mythic.lib.api.player.MMOPlayerData");
            boolean has = (boolean) mmoDataClass.getMethod("has", OfflinePlayer.class).invoke(null, caster);
            if (!has) return baseDamage;

            Object mmoData = mmoDataClass.getMethod("get", OfflinePlayer.class).invoke(null, caster);
            Object statMap = mmoData.getClass().getMethod("getStatMap").invoke(mmoData);
            Method getStat = statMap.getClass().getMethod("getStat", String.class);

            Object magicStat = getStat.invoke(statMap, "MAGIC_DAMAGE");
            Object skillStat = getStat.invoke(statMap, "SKILL_DAMAGE");

            double magicBonus = magicStat != null ? (double) magicStat.getClass().getMethod("getTotal").invoke(magicStat) : 0.0;
            double skillBonus = skillStat != null ? (double) skillStat.getClass().getMethod("getTotal").invoke(skillStat) : 0.0;

            return baseDamage * (1.0 + (magicBonus + skillBonus) / 100.0);
        } catch (Exception ignored) {
            return baseDamage;
        }
    }

    public Entity spawnModelEngineVfx(Location loc, String primaryModel, String fallbackModel, int durationTicks, List<Entity> tracker) {
        if (!Bukkit.getPluginManager().isPluginEnabled("ModelEngine")) return null;
        try {
            Class<?> apiClass = Class.forName("com.ticxo.modelengine.api.ModelEngineAPI");
            Method getBlueprint = apiClass.getMethod("getBlueprint", String.class);

            String chosen = getBlueprint.invoke(null, primaryModel) != null ? primaryModel
                    : (getBlueprint.invoke(null, fallbackModel) != null ? fallbackModel : null);
            if (chosen == null) return null;

            Interaction anchor = loc.getWorld().spawn(loc, Interaction.class, entity -> {
                entity.setInteractionWidth(0.1f);
                entity.setInteractionHeight(0.1f);
                entity.setResponsive(false);
            });
            tracker.add(anchor);

            Object modeledEntity = apiClass.getMethod("createModeledEntity", Entity.class).invoke(null, anchor);
            Object activeModel = apiClass.getMethod("createActiveModel", String.class).invoke(null, chosen);

            Class<?> activeModelClass = Class.forName("com.ticxo.modelengine.api.model.ActiveModel");
            modeledEntity.getClass().getMethod("addModel", activeModelClass, boolean.class).invoke(modeledEntity, activeModel, true);

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                try {
                    modeledEntity.getClass().getMethod("destroy").invoke(modeledEntity);
                } catch (Exception ignored) {
                }
                if (anchor.isValid()) anchor.remove();
                tracker.remove(anchor);
            }, durationTicks);

            return anchor;
        } catch (Exception ignored) {
            return null;
        }
    }

    public String parseItemsAdderGlyph(String glyphName) {
        if (!Bukkit.getPluginManager().isPluginEnabled("ItemsAdder")) return null;
        try {
            Class<?> wrapperClass = Class.forName("dev.lone.itemsadder.api.FontImages.FontImageWrapper");
            String parsed = (String) wrapperClass.getMethod("replaceFontImages", String.class).invoke(null, glyphName);
            return !parsed.equals(glyphName) ? parsed : null;
        } catch (Exception ignored) {
            return null;
        }
    }

    public void castMythicSkill(Player caster, String skillName) {
        if (skillName == null || skillName.isEmpty() || !Bukkit.getPluginManager().isPluginEnabled("MythicMobs")) return;
        try {
            Class<?> mythicBukkitClass = Class.forName("io.lumine.mythic.bukkit.MythicBukkit");
            Object inst = mythicBukkitClass.getMethod("inst").invoke(null);
            Object helper = inst.getClass().getMethod("getAPIHelper").invoke(inst);
            helper.getClass().getMethod("castSkill", Entity.class, String.class).invoke(helper, caster, skillName);
        } catch (Exception ignored) {
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public void registerMythicMobsMechanic(GenesisGripExecutor executor) {
        if (!Bukkit.getPluginManager().isPluginEnabled("MythicMobs")) return;
        try {
            Class<? extends Event> loadEventClass = (Class<? extends Event>) Class.forName("io.lumine.mythic.bukkit.events.MythicMechanicLoadEvent");
            Class<?> iNoTargetSkillClass = Class.forName("io.lumine.mythic.api.skills.INoTargetSkill");
            Class<? extends Enum> skillResultClass = (Class<? extends Enum>) Class.forName("io.lumine.mythic.api.skills.SkillResult");

            Bukkit.getPluginManager().registerEvent(loadEventClass, this, EventPriority.NORMAL, (listener, event) -> {
                try {
                    String mechName = (String) event.getClass().getMethod("getMechanicName").invoke(event);
                    if (!"genesisgrip".equalsIgnoreCase(mechName)) return;

                    Object lineConfig = event.getClass().getMethod("getConfig").invoke(event);
                    Method getDouble = lineConfig.getClass().getMethod("getDouble", String[].class, double.class);
                    Method getInt = lineConfig.getClass().getMethod("getInt", String[].class, int.class);

                    double damage = (double) getDouble.invoke(lineConfig, new String[]{"damage", "d"}, plugin.getConfig().getDouble("skill.base-damage", 18.0));
                    double radius = (double) getDouble.invoke(lineConfig, new String[]{"radius", "r"}, plugin.getConfig().getDouble("skill.radius", 4.5));
                    int duration = (int) getInt.invoke(lineConfig, new String[]{"duration", "dur"}, plugin.getConfig().getInt("skill.field-duration-ticks", 90));

                    Object proxyMechanic = Proxy.newProxyInstance(
                            iNoTargetSkillClass.getClassLoader(),
                            new Class<?>[]{iNoTargetSkillClass},
                            (proxy, method, args) -> {
                                if ("cast".equals(method.getName()) && args != null && args.length > 0) {
                                    Object meta = args[0];
                                    Object caster = meta.getClass().getMethod("getCaster").invoke(meta);
                                    Object absEntity = caster.getClass().getMethod("getEntity").invoke(caster);
                                    Object bukkitEntity = absEntity.getClass().getMethod("getBukkitEntity").invoke(absEntity);
                                    if (bukkitEntity instanceof Player player) {
                                        executor.castGenesisGrip(player, damage, radius, duration);
                                        return Enum.valueOf(skillResultClass, "SUCCESS");
                                    }
                                    return Enum.valueOf(skillResultClass, "CONDITION_FAILED");
                                }
                                return null;
                            }
                    );

                    Class<?> iSkillClass = Class.forName("io.lumine.mythic.api.skills.ISkill");
                    event.getClass().getMethod("register", iSkillClass).invoke(event, proxyMechanic);
                } catch (Exception ignored) {
                }
            }, plugin);
        } catch (Exception ignored) {
        }
    }
}
