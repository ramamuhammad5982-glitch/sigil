package id.wyn.illusionist.hook;

import id.wyn.illusionist.IllusionistSigilAddon;
import id.wyn.illusionist.core.SolsticeMuzzleExecutor;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class PluginBridgeManager implements Listener {

    private final IllusionistSigilAddon plugin;
    private final MiniMessage mm = MiniMessage.miniMessage();

    public PluginBridgeManager(IllusionistSigilAddon plugin) {
        this.plugin = plugin;
    }

    public String getActiveHooksSummary() {
        List<String> active = new ArrayList<>();
        for (String name : List.of("MythicLib", "MMOItems", "MythicMobs", "ItemsAdder", "ModelEngine")) {
            if (Bukkit.getPluginManager().isPluginEnabled(name)) {
                active.add(name);
            }
        }
        return active.isEmpty() ? "Standalone" : String.join(", ", active);
    }


    public ItemStack createSummonedWeaponForSpec(String summonSpec, Material fallbackMat, int fallbackCmd, String fallbackName, List<Integer> preferredCmds) {
        if (summonSpec != null && !summonSpec.isBlank() && !"AUTO".equalsIgnoreCase(summonSpec)) {
            String upper = summonSpec.trim().toUpperCase(Locale.ROOT);
            if (upper.startsWith("MMOITEMS:")) {
                String[] parts = summonSpec.trim().split(":", 3);
                if (parts.length == 3) {
                    ItemStack built = buildMmoItemAnyType(List.of(parts[1]), parts[2]);
                    if (built != null) return built;
                    ItemStack anyType = buildMmoItemAnyType(List.of("SWORD", "GUN", "PISTOL", "FIREARM", "WEAPON", "STAFF", "CATALYST", "BOW", "CROSSBOW", "MISCELLANEOUS"), parts[2]);
                    if (anyType != null) return anyType;
                    ItemStack iaFallback = buildItemsAdderItem(parts[2].toLowerCase(Locale.ROOT));
                    if (iaFallback != null) return iaFallback;
                    ItemStack mmFallback = buildMythicItem(parts[2]);
                    if (mmFallback != null) return mmFallback;
                }
            } else if (upper.startsWith("ITEMSADDER:")) {
                ItemStack built = buildItemsAdderItem(summonSpec.trim().substring("ITEMSADDER:".length()));
                if (built != null) return built;
            } else if (upper.startsWith("MYTHICMOBS:")) {
                ItemStack built = buildMythicItem(summonSpec.trim().substring("MYTHICMOBS:".length()));
                if (built != null) return built;
            } else if (upper.startsWith("VANILLA:")) {
                Material m = Material.matchMaterial(summonSpec.trim().substring("VANILLA:".length()));
                if (m != null && m != Material.AIR) {
                    fallbackMat = m;
                }
            }
        }

        Material mat = (fallbackMat != null && fallbackMat != Material.AIR) ? fallbackMat : Material.DIAMOND_SWORD;
        ItemStack stack = new ItemStack(mat, 1);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            if (fallbackName != null && !fallbackName.isBlank()) {
                meta.displayName(mm.deserialize(fallbackName));
            }
            if (fallbackCmd > 0) {
                meta.setCustomModelData(fallbackCmd);
            } else if (preferredCmds != null && !preferredCmds.isEmpty() && preferredCmds.get(0) > 0) {
                meta.setCustomModelData(preferredCmds.get(0));
            }
            stack.setItemMeta(meta);
        }
        return stack;
    }

    public ItemStack createSummonedPistol(List<String> preferredIds, List<Integer> preferredCmds) {
        String spec = plugin.getConfig().getString("weapon-swap.summon-item", "AUTO").trim();
        String upperSpec = spec.toUpperCase(Locale.ROOT);
        List<String> mmoTypes = getCandidateMmoTypes();

        if (upperSpec.startsWith("MMOITEMS:")) {
            String[] parts = spec.split(":", 3);
            if (parts.length == 3) {
                ItemStack built = buildMmoItemAnyType(List.of(parts[1]), parts[2]);
                if (built != null) return built;
            }
        } else if (upperSpec.startsWith("ITEMSADDER:")) {
            String namespacedId = spec.substring("ITEMSADDER:".length());
            ItemStack built = buildItemsAdderItem(namespacedId);
            if (built != null) return built;
        } else if (upperSpec.startsWith("MYTHICMOBS:")) {
            String mythicId = spec.substring("MYTHICMOBS:".length());
            ItemStack built = buildMythicItem(mythicId);
            if (built != null) return built;
        } else if (upperSpec.startsWith("VANILLA:")) {
            Material mat = Material.matchMaterial(spec.substring("VANILLA:".length()));
            if (mat != null && mat != Material.AIR) {
                return buildStyledItem(mat, preferredCmds);
            }
        } else {
            if (preferredIds != null) {
                for (String candidate : preferredIds) {
                    if (!candidate.contains(":")) {
                        ItemStack mmo = buildMmoItemAnyType(mmoTypes, candidate);
                        if (mmo != null) return mmo;
                    }

                    ItemStack ia = buildItemsAdderItem(candidate);
                    if (ia != null) return ia;

                    ItemStack mythic = buildMythicItem(candidate);
                    if (mythic != null) return mythic;
                }
            }
            // Juga coba ID bawaan Awakened Gunslinger secara langsung jika preferredIds kosong/belum cocok
            ItemStack gunslingerMmo = buildMmoItemAnyType(List.of("SWORD", "GUN", "WEAPON"), "awakened_gunslinger_doomblaster");
            if (gunslingerMmo != null) return gunslingerMmo;
            ItemStack gunslingerMythic = buildMythicItem("awakened_gunslinger_doomblaster");
            if (gunslingerMythic != null) return gunslingerMythic;
            ItemStack gunslingerIa = buildItemsAdderItem("awakened_gunslinger:awakened_gunslinger_doomblaster");
            if (gunslingerIa != null) return gunslingerIa;
        }

        String matName = plugin.getConfig().getString("weapon-swap.summon-material", "CROSSBOW");
        Material mat = Material.matchMaterial(matName);
        if (mat == null || mat == Material.AIR) {
            mat = Material.CROSSBOW;
        }
        ItemStack fallback = buildStyledItem(mat, preferredCmds);
        plugin.getLogger().info("[WeaponSwap] Menggunakan fallback item pistol (" + mat.name() + ") karena item MMOItems/ItemsAdder/MythicMobs tidak ditemukan.");
        return fallback;
    }

    private List<String> getCandidateMmoTypes() {
        List<String> types = new ArrayList<>();
        String configured = plugin.getConfig().getString("weapon-swap.summon-mmoitems-type", "GUN");
        if (configured != null && !configured.isBlank()) {
            for (String part : configured.split(",")) {
                String t = part.trim().toUpperCase(Locale.ROOT);
                if (!t.isEmpty() && !types.contains(t)) {
                    types.add(t);
                }
            }
        }
        for (String fallbackType : List.of("GUN", "PISTOL", "FIREARM", "WEAPON", "SWORD", "STAFF", "CATALYST", "BOW", "CROSSBOW", "MISCELLANEOUS")) {
            if (!types.contains(fallbackType)) {
                types.add(fallbackType);
            }
        }
        return types;
    }


    public ItemStack giveMmoItemViaCommand(Player player, String typeId, String itemId, int targetSlot) {
        if (player == null || !player.isOnline()) return null;
        String cleanType = (typeId == null || typeId.isBlank()) ? "SWORD" : typeId.trim().toUpperCase(Locale.ROOT);
        String cleanId = (itemId == null || itemId.isBlank()) ? "" : itemId.trim().toUpperCase(Locale.ROOT);
        if (cleanId.isEmpty()) return null;

        PlayerInventory inv = player.getInventory();
        int prevSlot = inv.getHeldItemSlot();
        int desiredSlot = (targetSlot >= 0 && targetSlot < inv.getSize()) ? targetSlot : prevSlot;

        // Snapshot sebelum /mi give agar bisa mendeteksi item baru yang masuk ke inventory
        ItemStack[] beforeContents = new ItemStack[inv.getSize()];
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack s = inv.getItem(i);
            beforeContents[i] = (s != null) ? s.clone() : null;
        }

        String template = plugin.getConfig().getString("weapon-swap.mi-give-command-format", "mi give {type} {id} {player}");
        String cmd = template
                .replace("{type}", cleanType)
                .replace("{id}", cleanId)
                .replace("{player}", player.getName())
                .trim();
        if (cmd.startsWith("/")) {
            cmd = cmd.substring(1).trim();
        }

        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        plugin.getLogger().info("[WeaponSwap] Menjalankan /" + cmd);

        // Cari slot baru atau slot yang berubah isinya
        int foundSlot = -1;
        ItemStack foundStack = null;
        for (int i = 0; i < inv.getSize(); i++) {
            ItemStack now = inv.getItem(i);
            ItemStack before = beforeContents[i];
            if (now != null && now.getType() != Material.AIR) {
                if (before == null || before.getType() == Material.AIR || !before.isSimilar(now) || now.getAmount() != before.getAmount()) {
                    foundSlot = i;
                    foundStack = now.clone();
                    break;
                }
            }
        }

        if (foundStack != null && foundSlot != -1) {
            if (foundSlot != desiredSlot && desiredSlot >= 0 && desiredSlot < 9) {
                ItemStack displaced = inv.getItem(desiredSlot);
                inv.setItem(desiredSlot, foundStack);
                inv.setItem(foundSlot, displaced);
                inv.setHeldItemSlot(desiredSlot);
                return foundStack;
            } else if (desiredSlot >= 0 && desiredSlot < 9) {
                inv.setHeldItemSlot(desiredSlot);
            }
            return foundStack;
        }

        // Fallback jika command belum langsung mengisi inventory sinkron: coba bangun via API
        return buildMmoItemAnyType(List.of(cleanType, "SWORD", "GUN", "WEAPON", "STAFF"), cleanId);
    }

    private ItemStack buildMmoItemAnyType(List<String> typeCandidates, String itemId) {
        if (!Bukkit.getPluginManager().isPluginEnabled("MMOItems")) return null;
        for (String typeId : typeCandidates) {
            ItemStack built = buildMmoItem(typeId, itemId);
            if (built != null) return built;
        }
        return null;
    }

    private ItemStack buildStyledItem(Material mat, List<Integer> preferredCmds) {
        ItemStack stack = new ItemStack(mat, 1);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            String nameRaw = plugin.getConfig().getString(
                    "weapon-swap.summon-display-name",
                    "<gradient:#FF5555:#FFD06C>Doomblaster</gradient>"
            );
            meta.displayName(mm.deserialize(nameRaw));
            if (plugin.getConfig().contains("weapon-swap.summon-custom-model-data")) {
                meta.setCustomModelData(plugin.getConfig().getInt("weapon-swap.summon-custom-model-data", 2095));
            } else if (preferredCmds != null && !preferredCmds.isEmpty()) {
                meta.setCustomModelData(preferredCmds.get(0));
            }
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack buildMmoItem(String typeId, String itemId) {
        if (!Bukkit.getPluginManager().isPluginEnabled("MMOItems")) return null;
        try {
            Class<?> mmoItemsClass = Class.forName("net.Indyuce.mmoitems.MMOItems");
            Object pluginInst = mmoItemsClass.getMethod("getPlugin").invoke(null);
            Object typeManager = pluginInst.getClass().getMethod("getTypes").invoke(pluginInst);
            Object typeObj = typeManager.getClass().getMethod("get", String.class).invoke(typeManager, typeId.toUpperCase(Locale.ROOT));
            if (typeObj == null) return null;

            Object itemManager = pluginInst.getClass().getMethod("getItems").invoke(pluginInst);
            Method getItem = null;
            for (Method m : itemManager.getClass().getMethods()) {
                if (m.getName().equals("getItem") && m.getParameterCount() == 2) {
                    getItem = m;
                    break;
                }
            }
            if (getItem == null) return null;

            Object mmoItem = getItem.invoke(itemManager, typeObj, itemId.toUpperCase(Locale.ROOT));
            if (mmoItem == null) {
                mmoItem = getItem.invoke(itemManager, typeObj, itemId);
            }
            if (mmoItem == null) return null;

            Object built = mmoItem.getClass().getMethod("newBuilder").invoke(mmoItem);
            Object builtItem = built.getClass().getMethod("build").invoke(built);
            if (builtItem == null) return null;

            Object stackObj = null;
            for (Method bm : builtItem.getClass().getMethods()) {
                if (bm.getName().equals("getNewStack") && bm.getParameterCount() == 0) {
                    stackObj = bm.invoke(builtItem);
                    break;
                }
            }
            if (stackObj == null) {
                for (Method bm : builtItem.getClass().getMethods()) {
                    if (bm.getName().equals("getItemStack") && bm.getParameterCount() == 0) {
                        stackObj = bm.invoke(builtItem);
                        break;
                    }
                }
            }
            if (stackObj instanceof ItemStack is && is.getType() != Material.AIR) {
                plugin.getLogger().info("[WeaponSwap] Berhasil mengambil item MMOItems: " + typeId + ":" + itemId);
                return is.clone();
            }
        } catch (Exception ignored) {
        }

        // Fallback command /mi give <TYPE> <ID> jika API langsung tidak mengembalikan item
        if (plugin.getConfig().getBoolean("weapon-swap.allow-mi-give-command", false)) {
            String cmd = "mi give " + typeId.toUpperCase(Locale.ROOT) + " " + itemId.toUpperCase(Locale.ROOT);
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            plugin.getLogger().info("[WeaponSwap] Menjalankan command fallback: /" + cmd);
        }
        return null;
    }

    private ItemStack buildItemsAdderItem(String namespacedId) {
        if (namespacedId == null || !Bukkit.getPluginManager().isPluginEnabled("ItemsAdder")) return null;
        try {
            Class<?> customStackClass = Class.forName("dev.lone.itemsadder.api.CustomStack");
            Object customStack = customStackClass.getMethod("getInstance", String.class).invoke(null, namespacedId);
            if (customStack != null) {
                Object itemStack = customStackClass.getMethod("getItemStack").invoke(customStack);
                if (itemStack instanceof ItemStack is && is.getType() != Material.AIR) {
                    plugin.getLogger().info("[WeaponSwap] Berhasil mengambil item ItemsAdder: " + namespacedId);
                    return is.clone();
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    private ItemStack buildMythicItem(String mythicId) {
        if (mythicId == null || !Bukkit.getPluginManager().isPluginEnabled("MythicMobs")) return null;
        try {
            Class<?> mythicBukkitClass = Class.forName("io.lumine.mythic.bukkit.MythicBukkit");
            Object inst = mythicBukkitClass.getMethod("inst").invoke(null);
            Object itemManager = inst.getClass().getMethod("getItemManager").invoke(inst);
            Object generated = itemManager.getClass().getMethod("getItemStack", String.class).invoke(itemManager, mythicId);
            if (generated instanceof ItemStack is && is.getType() != Material.AIR) {
                plugin.getLogger().info("[WeaponSwap] Berhasil mengambil item MythicMobs: " + mythicId);
                return is.clone();
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    public boolean isIllusionistTriggerItem(ItemStack item) {
        if (item == null) return false;

        boolean matchKeyword = plugin.getConfig().getBoolean("hooks.match-keyword-in-id-or-name", true);

        String mmoId = getMmoItemId(item);
        if (mmoId != null) {
            for (String allowed : plugin.getConfig().getStringList("hooks.mmoitems.trigger-ids")) {
                if (allowed.equalsIgnoreCase(mmoId)) return true;
            }
            if (matchKeyword && containsIllusionistKeyword(mmoId)) {
                return true;
            }
        }

        String iaId = getItemsAdderId(item);
        if (iaId != null) {
            for (String allowed : plugin.getConfig().getStringList("hooks.itemsadder.trigger-items")) {
                if (allowed.equalsIgnoreCase(iaId)) return true;
            }
            if (plugin.getConfig().getBoolean("hooks.match-illusionist-namespace", true)
                    && iaId.toLowerCase(Locale.ROOT).startsWith("illusionist:")) {
                return true;
            }
            if (matchKeyword && containsIllusionistKeyword(iaId)) {
                return true;
            }
        }

        if (matchKeyword && item.hasItemMeta()) {
            ItemMeta meta = item.getItemMeta();
            Component displayName = meta.displayName();
            if (displayName != null) {
                String plain = PlainTextComponentSerializer.plainText().serialize(displayName);
                if (containsIllusionistKeyword(plain)) {
                    return true;
                }
            }
        }

        return false;
    }

    public boolean isPreferredBattleWeapon(ItemStack item, List<String> targetIds, List<String> targetNames, List<Integer> targetCmds) {
        if (item == null || item.getType() == Material.AIR) return false;

        String mmoId = getMmoItemId(item);
        String iaId = getItemsAdderId(item);
        String mythicId = getMythicItemId(item);
        if (targetIds != null) {
            for (String id : targetIds) {
                if (mmoId != null && id.equalsIgnoreCase(mmoId)) return true;
                if (iaId != null && id.equalsIgnoreCase(iaId)) return true;
                if (mythicId != null && id.equalsIgnoreCase(mythicId)) return true;
            }
        }

        if (item.hasItemMeta()) {
            ItemMeta meta = item.getItemMeta();

            if (targetCmds != null && !targetCmds.isEmpty() && meta.hasCustomModelData()) {
                if (targetCmds.contains(meta.getCustomModelData())) {
                    return true;
                }
            }

            if (targetNames != null && !targetNames.isEmpty()) {
                Component displayName = meta.displayName();
                if (displayName != null) {
                    String plain = PlainTextComponentSerializer.plainText().serialize(displayName).toLowerCase(Locale.ROOT);
                    for (String targetName : targetNames) {
                        if (plain.contains(targetName.toLowerCase(Locale.ROOT))) {
                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    public boolean isPistolWeapon(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;

        List<String> preferredIds = plugin.getConfig().getStringList("weapon-swap.preferred-weapons");
        List<String> preferredNames = plugin.getConfig().getStringList("weapon-swap.preferred-names");
        List<Integer> preferredCmds = plugin.getConfig().getIntegerList("weapon-swap.preferred-custom-model-data");
        if (isPreferredBattleWeapon(item, preferredIds, preferredNames, preferredCmds)) {
            return true;
        }

        String mmoId = getMmoItemId(item);
        String iaId = getItemsAdderId(item);
        String mythicId = getMythicItemId(item);
        for (String id : List.of(mmoId, iaId, mythicId)) {
            if (id != null) {
                String lower = id.toLowerCase(Locale.ROOT);
                if (lower.contains("pistol") || lower.contains("blaster") || lower.contains("eagle") || lower.contains("gun")) {
                    return true;
                }
            }
        }

        if (item.hasItemMeta()) {
            ItemMeta meta = item.getItemMeta();
            Component displayName = meta.displayName();
            if (displayName != null) {
                String plain = PlainTextComponentSerializer.plainText().serialize(displayName).toLowerCase(Locale.ROOT);
                if (plain.contains("pistol") || plain.contains("blaster") || plain.contains("eagle") || plain.contains("gun")) {
                    return true;
                }
            }
        }

        return false;
    }

    public boolean isBattleWeaponItem(ItemStack item) {
        if (item == null || item.getType() == Material.AIR) return false;
        if (getMmoItemId(item) != null || getItemsAdderId(item) != null || getMythicItemId(item) != null) return true;

        String matName = item.getType().name();
        return matName.endsWith("_SWORD")
                || matName.endsWith("_AXE")
                || matName.equals("TRIDENT")
                || matName.equals("MACE")
                || matName.equals("BOW")
                || matName.equals("CROSSBOW")
                || matName.equals("BLAZE_ROD")
                || matName.equals("STICK");
    }

    private boolean containsIllusionistKeyword(String text) {
        if (text == null) return false;
        String lower = text.toLowerCase(Locale.ROOT);
        return lower.contains("illusionist")
                || lower.contains("mystical_card")
                || lower.contains("mystical card")
                || lower.contains("solstice_muzzle")
                || lower.contains("solstice muzzle")
                || lower.contains("genesis_grip")
                || lower.contains("genesis grip");
    }

    public String getMmoItemId(ItemStack item) {
        if (item == null) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return null;
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        NamespacedKey mmoKey = new NamespacedKey("mmoitems", "mmoitems_item_id");
        return pdc.has(mmoKey, PersistentDataType.STRING) ? pdc.get(mmoKey, PersistentDataType.STRING) : null;
    }

    public String getMythicItemId(ItemStack item) {
        if (item == null) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return null;
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        NamespacedKey mythicKey = new NamespacedKey("mythicmobs", "type");
        return pdc.has(mythicKey, PersistentDataType.STRING) ? pdc.get(mythicKey, PersistentDataType.STRING) : null;
    }

    public String getItemsAdderId(ItemStack item) {
        if (item == null || !Bukkit.getPluginManager().isPluginEnabled("ItemsAdder")) return null;
        try {
            Class<?> customStackClass = Class.forName("dev.lone.itemsadder.api.CustomStack");
            Object customStack = customStackClass.getMethod("byItemStack", ItemStack.class).invoke(null, item);
            if (customStack != null) {
                return (String) customStackClass.getMethod("getNamespacedID").invoke(customStack);
            }
        } catch (Exception ignored) {
        }
        return null;
    }

    public double computeMythicLibMagicDamage(Player caster, double baseDamage) {
        if (!Bukkit.getPluginManager().isPluginEnabled("MythicLib")) return baseDamage;
        try {
            Class<?> mmoDataClass = Class.forName("io.lumine.mythic.lib.api.player.MMOPlayerData");
            boolean has = (boolean) mmoDataClass.getMethod("has", OfflinePlayer.class).invoke(null, caster);
            if (!has) return baseDamage;

            Object mmoData = mmoDataClass.getMethod("get", OfflinePlayer.class).invoke(null, caster);
            Object statMap = mmoData.getClass().getMethod("getStatMap").invoke(mmoData);
            Method getStat = statMap.getClass().getMethod("getStat", String.class);

            Object magicStat = getStat.invoke(statMap, "MAGIC_DAMAGE");
            Object skillStat = getStat.invoke(statMap, "SKILL_DAMAGE");

            double magicBonus = magicStat != null ? (double) magicStat.getClass().getMethod("getTotal").invoke(magicStat) : 0.0;
            double skillBonus = skillStat != null ? (double) skillStat.getClass().getMethod("getTotal").invoke(skillStat) : 0.0;

            return baseDamage * (1.0 + (magicBonus + skillBonus) / 100.0);
        } catch (Exception ignored) {
            return baseDamage;
        }
    }

    public Entity spawnModelEngineVfx(Location loc, String primaryModel, String fallbackModel, int durationTicks, List<Entity> tracker) {
        if (!Bukkit.getPluginManager().isPluginEnabled("ModelEngine")) return null;
        try {
            Class<?> apiClass = Class.forName("com.ticxo.modelengine.api.ModelEngineAPI");
            Method getBlueprint = apiClass.getMethod("getBlueprint", String.class);

            String chosen = (primaryModel != null && !primaryModel.isEmpty() && getBlueprint.invoke(null, primaryModel) != null) ? primaryModel
                    : ((fallbackModel != null && !fallbackModel.isEmpty() && getBlueprint.invoke(null, fallbackModel) != null) ? fallbackModel : null);
            if (chosen == null) return null;

            Interaction anchor = loc.getWorld().spawn(loc, Interaction.class, entity -> {
                entity.setInteractionWidth(0.0f);
                entity.setInteractionHeight(0.0f);
                entity.setResponsive(false);
                entity.setInvulnerable(true);
            });
            tracker.add(anchor);

            Object modeledEntity = apiClass.getMethod("createModeledEntity", Entity.class).invoke(null, anchor);
            Object activeModel = apiClass.getMethod("createActiveModel", String.class).invoke(null, chosen);

            Class<?> activeModelClass = Class.forName("com.ticxo.modelengine.api.model.ActiveModel");
            modeledEntity.getClass().getMethod("addModel", activeModelClass, boolean.class).invoke(modeledEntity, activeModel, true);

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                try {
                    modeledEntity.getClass().getMethod("destroy").invoke(modeledEntity);
                } catch (Exception ignored) {
                }
                if (anchor.isValid()) anchor.remove();
                tracker.remove(anchor);
            }, durationTicks);

            return anchor;
        } catch (Exception ignored) {
            return null;
        }
    }

    public String parseItemsAdderGlyph(String glyphName) {
        if (!Bukkit.getPluginManager().isPluginEnabled("ItemsAdder")) return null;
        try {
            Class<?> wrapperClass = Class.forName("dev.lone.itemsadder.api.FontImages.FontImageWrapper");
            String parsed = (String) wrapperClass.getMethod("replaceFontImages", String.class).invoke(null, glyphName);
            return !parsed.equals(glyphName) ? parsed : null;
        } catch (Exception ignored) {
            return null;
        }
    }

    public void castMythicSkill(Player caster, String skillName) {
        if (skillName == null || skillName.isEmpty() || !Bukkit.getPluginManager().isPluginEnabled("MythicMobs")) return;
        boolean casted = false;
        try {
            Class<?> mythicBukkitClass = Class.forName("io.lumine.mythic.bukkit.MythicBukkit");
            Object inst = mythicBukkitClass.getMethod("inst").invoke(null);
            Object helper = inst.getClass().getMethod("getAPIHelper").invoke(inst);
            for (Method m : helper.getClass().getMethods()) {
                if (m.getName().equals("castSkill") && m.getParameterCount() == 2) {
                    m.invoke(helper, caster, skillName);
                    casted = true;
                    break;
                }
            }
        } catch (Throwable t) {
            plugin.getLogger().warning("[WeaponSwap] Gagal castSkill MythicMobs '" + skillName + "' via APIHelper: " + t.getMessage());
        }

        // Fallback command /mm skills cast <skillName> jika APIHelper tidak mengeksekusi atau skill butuh cast dari caster/console
        if (!casted || plugin.getConfig().getBoolean("weapon-swap.pistol-skills.force-mm-command-fallback", true)) {
            String cmd = plugin.getConfig().getString("weapon-swap.pistol-skills.mm-cast-command", "mm skills cast {skill}")
                    .replace("{player}", caster.getName())
                    .replace("{skill}", skillName);
            if (cmd.startsWith("/")) cmd = cmd.substring(1);
            try {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
            } catch (Exception ex) {
                plugin.getLogger().warning("[WeaponSwap] Gagal menjalankan command MythicMobs: " + cmd + " (" + ex.getMessage() + ")");
            }
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public void registerMythicMobsMechanic(SolsticeMuzzleExecutor executor) {
        if (!Bukkit.getPluginManager().isPluginEnabled("MythicMobs")) return;
        try {
            Class<? extends Event> loadEventClass = (Class<? extends Event>) Class.forName("io.lumine.mythic.bukkit.events.MythicMechanicLoadEvent");
            Class<?> iNoTargetSkillClass = Class.forName("io.lumine.mythic.api.skills.INoTargetSkill");
            Class<? extends Enum> skillResultClass = (Class<? extends Enum>) Class.forName("io.lumine.mythic.api.skills.SkillResult");

            Bukkit.getPluginManager().registerEvent(loadEventClass, this, EventPriority.NORMAL, (listener, event) -> {
                try {
                    String mechName = (String) event.getClass().getMethod("getMechanicName").invoke(event);
                    if (!"solsticemuzzle".equalsIgnoreCase(mechName) && !"genesisgrip".equalsIgnoreCase(mechName)) return;

                    Object lineConfig = event.getClass().getMethod("getConfig").invoke(event);
                    Method getDouble = lineConfig.getClass().getMethod("getDouble", String[].class, double.class);
                    Method getInt = lineConfig.getClass().getMethod("getInt", String[].class, int.class);

                    double damage = (double) getDouble.invoke(lineConfig, new String[]{"damage", "d"}, plugin.getConfig().getDouble("skill.base-damage", 18.0));
                    double radius = (double) getDouble.invoke(lineConfig, new String[]{"radius", "r"}, plugin.getConfig().getDouble("skill.radius", 4.5));
                    int duration = (int) getInt.invoke(lineConfig, new String[]{"duration", "dur"}, plugin.getConfig().getInt("skill.field-duration-ticks", 90));

                    Object proxyMechanic = Proxy.newProxyInstance(
                            iNoTargetSkillClass.getClassLoader(),
                            new Class<?>[]{iNoTargetSkillClass},
                            (proxy, method, args) -> {
                                if ("cast".equals(method.getName()) && args != null && args.length > 0) {
                                    Object meta = args[0];
                                    Object caster = meta.getClass().getMethod("getCaster").invoke(meta);
                                    Object absEntity = caster.getClass().getMethod("getEntity").invoke(caster);
                                    Object bukkitEntity = absEntity.getClass().getMethod("getBukkitEntity").invoke(absEntity);
                                    if (bukkitEntity instanceof Player player) {
                                        executor.castSolsticeMuzzle(player, damage, radius, duration);
                                        return Enum.valueOf(skillResultClass, "SUCCESS");
                                    }
                                    return Enum.valueOf(skillResultClass, "CONDITION_FAILED");
                                }
                                return null;
                            }
                    );

                    Class<?> iSkillClass = Class.forName("io.lumine.mythic.api.skills.ISkill");
                    event.getClass().getMethod("register", iSkillClass).invoke(event, proxyMechanic);
                } catch (Exception ignored) {
                }
            }, plugin);
        } catch (Exception ignored) {
        }
    }
}
