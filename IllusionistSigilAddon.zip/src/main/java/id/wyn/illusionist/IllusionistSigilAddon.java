package id.wyn.illusionist;

import id.wyn.illusionist.core.OverheadWeaponManager;
import id.wyn.illusionist.core.WeaponSelectionGUI;
import id.wyn.illusionist.core.SolsticeMuzzleExecutor;
import id.wyn.illusionist.hook.PluginBridgeManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class IllusionistSigilAddon extends JavaPlugin implements Listener {

    private static IllusionistSigilAddon instance;
    private PluginBridgeManager bridge;
    private SolsticeMuzzleExecutor executor;
    private OverheadWeaponManager overheadManager;
    private WeaponSelectionGUI selectionGui;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.bridge = new PluginBridgeManager(this);
        this.overheadManager = new OverheadWeaponManager(this, bridge);
        this.executor = new SolsticeMuzzleExecutor(this, bridge, overheadManager);
        this.selectionGui = new WeaponSelectionGUI(this, bridge, executor);

        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getPluginManager().registerEvents(overheadManager, this);
        Bukkit.getPluginManager().registerEvents(selectionGui, this);
        bridge.registerMythicMobsMechanic(executor);
        overheadManager.start();

        getLogger().info("IllusionistSigilAddon aktif! Hook aktif -> " + bridge.getActiveHooksSummary());
    }

    @Override
    public void onDisable() {
        if (executor != null) {
            executor.cleanupAll();
        }
        if (overheadManager != null) {
            overheadManager.cleanupAll();
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteractItem(PlayerInteractEvent event) {
        if (event.getHand() != null && event.getHand() != EquipmentSlot.HAND) return;
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        if (item == null || item.getType() == Material.AIR) {
            item = player.getInventory().getItemInMainHand();
        }
        if (item == null || item.getType() == Material.AIR) return;

        Action action = event.getAction();
        if (executor != null && executor.isPostChantActive(player) && bridge.isPistolWeapon(item)) {
            if (action == Action.LEFT_CLICK_AIR || action == Action.LEFT_CLICK_BLOCK) {
                if (getConfig().getBoolean("weapon-swap.pistol-skills.enabled", true)) {
                    String skillMode = getConfig().getString("weapon-swap.pistol-skills.left-click-mode", "MYTHIC").toUpperCase(java.util.Locale.ROOT);
                    if (!"MYTHIC".equals(skillMode) && !"NATIVE_OR_MYTHIC".equals(skillMode)) {
                        event.setCancelled(true);
                    }
                    executor.triggerPistolSkill(player);
                    return;
                }
            }
            if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
                if (getConfig().getBoolean("weapon-swap.pistol-right-click-deactivate.enabled", true)) {
                    event.setCancelled(true);
                    executor.deactivateChantModeByPistol(player);
                    return;
                }
            }
        }

        if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
            handleRightClick(player, item, event);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInteractEntity(PlayerInteractEntityEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item == null || item.getType() == Material.AIR) return;

        if (executor != null && executor.isPostChantActive(player) && bridge.isPistolWeapon(item)) {
            if (getConfig().getBoolean("weapon-swap.pistol-right-click-deactivate.enabled", true)) {
                event.setCancelled(true);
                executor.deactivateChantModeByPistol(player);
                return;
            }
        }
        handleRightClick(player, item, event);
    }

    private void handleRightClick(Player player, ItemStack item, Cancellable event) {
        if (item == null || item.getType() == Material.AIR) return;

        if (!bridge.isIllusionistTriggerItem(item)) return;

        event.setCancelled(true);

        if (executor.isChanting(player)) return;

        long now = System.currentTimeMillis();
        long cdMillis = (long) (getConfig().getDouble("skill.cooldown-seconds", getConfig().getDouble("Skill.cooldown-seconds", 12.0)) * 1000L);
        long expire = cooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (now < expire) {
            double left = (expire - now) / 1000.0;
            player.sendActionBar(mm.deserialize("<#F5C542>Solstice Muzzle Cooldown: <white>" + String.format("%.1fs", left) + "</white></#F5C542>"));
            return;
        }

        if (getConfig().getBoolean("weapon-selection.open-gui-on-card-use", false)) {
            selectionGui.openSelectionMenu(player);
            return;
        }
        cooldowns.put(player.getUniqueId(), now + cdMillis);
        executor.castSolsticeMuzzle(
                player,
                getConfig().getDouble("skill.base-damage", getConfig().getDouble("Skill.base-damage", 18.0)),
                getConfig().getDouble("skill.radius", getConfig().getDouble("Skill.radius", 4.5)),
                getConfig().getInt("skill.field-duration-ticks", getConfig().getInt("Skill.field-duration-ticks", 90))
        );
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMoveDuringChant(PlayerMoveEvent event) {
        if (!getConfig().getBoolean("cinematic.lock-movement", true)) return;
        Player player = event.getPlayer();
        if (executor == null || !executor.isChanting(player)) return;

        Location from = event.getFrom();
        Location to = event.getTo();
        if (from.getX() != to.getX() || from.getZ() != to.getZ()) {
            Location locked = from.clone();
            locked.setY(to.getY());
            locked.setYaw(to.getYaw());
            locked.setPitch(to.getPitch());
            event.setTo(locked);
        }
    }

    @EventHandler
    public void onSneakSkip(PlayerToggleSneakEvent event) {
        if (event.isSneaking() && executor != null) {
            executor.skipCinematic(event.getPlayer());
        }
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        if (executor != null) {
            executor.cleanupPlayer(event.getEntity());
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        cooldowns.remove(uuid);
        if (executor != null) {
            executor.cleanupPlayer(event.getPlayer());
        }
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            if (overheadManager != null) {
                overheadManager.cleanupAll();
            }
            sender.sendMessage(mm.deserialize("<#F5C542>[Illusionist]</#F5C542> <white>Konfigurasi berhasil di-reload.</white>"));
            return true;
        }
        if (sender instanceof Player player) {
            executor.castSolsticeMuzzle(
                    player,
                    getConfig().getDouble("skill.base-damage", getConfig().getDouble("Skill.base-damage", 18.0)),
                    getConfig().getDouble("skill.radius", getConfig().getDouble("Skill.radius", 4.5)),
                    getConfig().getInt("skill.field-duration-ticks", getConfig().getInt("Skill.field-duration-ticks", 90))
            );
            return true;
        }
        return false;
    }

    public static IllusionistSigilAddon getInstance() {
        return instance;
    }
}
