package id.wyn.illusionist;

import id.wyn.illusionist.core.GenesisGripExecutor;
import id.wyn.illusionist.core.OverheadWeaponManager;
import id.wyn.illusionist.hook.PluginBridgeManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class IllusionistSigilAddon extends JavaPlugin implements Listener {

    private static IllusionistSigilAddon instance;
    private PluginBridgeManager bridge;
    private GenesisGripExecutor executor;
    private OverheadWeaponManager overheadManager;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastBoostClick = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.bridge = new PluginBridgeManager(this);
        this.executor = new GenesisGripExecutor(this, bridge);
        this.overheadManager = new OverheadWeaponManager(this, bridge);

        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getPluginManager().registerEvents(overheadManager, this);
        bridge.registerMythicMobsMechanic(executor);
        overheadManager.start();

        getLogger().info("IllusionistSigilAddon aktif! Hook aktif -> " + bridge.getActiveHooksSummary());
    }

    @Override
    public void onDisable() {
        if (executor != null) {
            executor.cleanupAll();
        }
        if (overheadManager != null) {
            overheadManager.cleanupAll();
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onRightClickCardOrSigil(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        handleCardOrSigilRightClick(player, item, event);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onRightClickEntityWithCard(PlayerInteractEntityEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (executor.isChanting(player) && bridge.isIllusionistCardOrSigil(item)) {
            event.setCancelled(true);
            tryAccelerateChant(player);
        }
    }

    private void handleCardOrSigilRightClick(Player player, ItemStack item, PlayerInteractEvent event) {
        if (item == null) return;

        // 1. Jika sedang nge-chant: klik kanan pada kartu / sigil akan memacu (boost) progres chant!
        if (executor.isChanting(player)) {
            if (bridge.isIllusionistCardOrSigil(item)) {
                event.setCancelled(true);
                tryAccelerateChant(player);
            }
            return;
        }

        // 2. Jika belum nge-chant: klik kanan pada Genesis Grip Sigil memulai chant
        if (!bridge.isGenesisGripSigil(item)) return;
        event.setCancelled(true);

        long now = System.currentTimeMillis();
        long cdMillis = (long) (getConfig().getDouble("skill.cooldown-seconds", 12.0) * 1000L);
        long expire = cooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (now < expire) {
            double left = (expire - now) / 1000.0;
            player.sendActionBar(mm.deserialize("<#F5C542>Genesis Grip Cooldown: <white>" + String.format("%.1fs", left) + "</white></#F5C542>"));
            return;
        }

        cooldowns.put(player.getUniqueId(), now + cdMillis);
        lastBoostClick.put(player.getUniqueId(), now);
        executor.castGenesisGrip(
                player,
                getConfig().getDouble("skill.base-damage", 18.0),
                getConfig().getDouble("skill.radius", 4.5),
                getConfig().getInt("skill.field-duration-ticks", 90)
        );
    }

    private void tryAccelerateChant(Player player) {
        long now = System.currentTimeMillis();
        long last = lastBoostClick.getOrDefault(player.getUniqueId(), 0L);
        if (now - last < 90L) return; // cegah double-fire dalam 1 klik
        lastBoostClick.put(player.getUniqueId(), now);

        int boostTicks = getConfig().getInt("skill.right-click-boost-ticks", 8);
        executor.accelerateChant(player, boostTicks);
    }

    @EventHandler
    public void onSneakSkip(PlayerToggleSneakEvent event) {
        if (event.isSneaking() && executor != null) {
            executor.skipCinematic(event.getPlayer());
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        cooldowns.remove(uuid);
        lastBoostClick.remove(uuid);
        if (executor != null) {
            executor.skipCinematic(event.getPlayer());
        }
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            if (overheadManager != null) {
                overheadManager.cleanupAll();
            }
            sender.sendMessage(mm.deserialize("<#F5C542>[Illusionist]</#F5C542> <white>Konfigurasi berhasil di-reload.</white>"));
            return true;
        }
        if (sender instanceof Player player) {
            executor.castGenesisGrip(
                    player,
                    getConfig().getDouble("skill.base-damage", 18.0),
                    getConfig().getDouble("skill.radius", 4.5),
                    getConfig().getInt("skill.field-duration-ticks", 90)
            );
            return true;
        }
        return false;
    }

    public static IllusionistSigilAddon getInstance() {
        return instance;
    }
}
