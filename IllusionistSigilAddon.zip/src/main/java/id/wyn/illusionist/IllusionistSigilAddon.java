package id.wyn.illusionist;

import id.wyn.illusionist.core.GenesisGripExecutor;
import id.wyn.illusionist.hook.PluginBridgeManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class IllusionistSigilAddon extends JavaPlugin implements Listener {

    private static IllusionistSigilAddon instance;
    private PluginBridgeManager bridge;
    private GenesisGripExecutor executor;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private final Map<UUID, Long> cooldowns = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.bridge = new PluginBridgeManager(this);
        this.executor = new GenesisGripExecutor(this, bridge);

        Bukkit.getPluginManager().registerEvents(this, this);
        bridge.registerMythicMobsMechanic(executor);

        getLogger().info("IllusionistSigilAddon aktif! Hook aktif -> " + bridge.getActiveHooksSummary());
    }

    @Override
    public void onDisable() {
        if (executor != null) {
            executor.cleanupAll();
        }
    }

    @EventHandler
    public void onRightClickSigil(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        if (item == null || !bridge.isGenesisGripSigil(item)) return;

        event.setCancelled(true);

        long now = System.currentTimeMillis();
        long cdMillis = (long) (getConfig().getDouble("skill.cooldown-seconds", 12.0) * 1000L);
        long expire = cooldowns.getOrDefault(player.getUniqueId(), 0L);
        if (now < expire) {
            double left = (expire - now) / 1000.0;
            player.sendActionBar(mm.deserialize("<#F5C542>Genesis Grip Cooldown: <white>" + String.format("%.1fs", left) + "</white></#F5C542>"));
            return;
        }

        cooldowns.put(player.getUniqueId(), now + cdMillis);
        executor.castGenesisGrip(
                player,
                getConfig().getDouble("skill.base-damage", 18.0),
                getConfig().getDouble("skill.radius", 4.5),
                getConfig().getInt("skill.field-duration-ticks", 90)
        );
    }

    @EventHandler
    public void onSneakSkip(PlayerToggleSneakEvent event) {
        if (event.isSneaking() && executor != null) {
            executor.skipCinematic(event.getPlayer());
        }
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            reloadConfig();
            sender.sendMessage(mm.deserialize("<#F5C542>[Illusionist]</#F5C542> <white>Konfigurasi berhasil di-reload.</white>"));
            return true;
        }
        if (sender instanceof Player player) {
            executor.castGenesisGrip(
                    player,
                    getConfig().getDouble("skill.base-damage", 18.0),
                    getConfig().getDouble("skill.radius", 4.5),
                    getConfig().getInt("skill.field-duration-ticks", 90)
            );
            return true;
        }
        return false;
    }

    public static IllusionistSigilAddon getInstance() {
        return instance;
    }
}
