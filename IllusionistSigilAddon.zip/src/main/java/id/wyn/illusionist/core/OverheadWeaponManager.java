package id.wyn.illusionist.core;

import id.wyn.illusionist.IllusionistSigilAddon;
import id.wyn.illusionist.hook.PluginBridgeManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class OverheadWeaponManager implements Listener {

    private final IllusionistSigilAddon plugin;
    private final PluginBridgeManager bridge;
    private final Map<UUID, OverheadEntry> displays = new ConcurrentHashMap<>();
    private BukkitTask task;

    private static final class OverheadEntry {
        final ItemDisplay itemDisplay;
        final Entity modelAnchor;
        String itemFingerprint;
        float angleDeg;

        OverheadEntry(ItemDisplay itemDisplay, Entity modelAnchor, String itemFingerprint) {
            this.itemDisplay = itemDisplay;
            this.modelAnchor = modelAnchor;
            this.itemFingerprint = itemFingerprint;
            this.angleDeg = 0f;
        }
    }

    public OverheadWeaponManager(IllusionistSigilAddon plugin, PluginBridgeManager bridge) {
        this.plugin = plugin;
        this.bridge = bridge;
    }

    public void start() {
        this.task = Bukkit.getScheduler().runTaskTimer(plugin, this::tickAll, 1L, 1L);
    }

    private void tickAll() {
        if (!plugin.getConfig().getBoolean("overhead-display.enabled", true)) {
            cleanupAll();
            return;
        }

        float scale = (float) plugin.getConfig().getDouble("overhead-display.scale", 2.35);
        double heightOffset = plugin.getConfig().getDouble("overhead-display.height-offset", 2.75);
        float rotSpeed = (float) plugin.getConfig().getDouble("overhead-display.rotation-speed", 5.5);

        Set<UUID> online = new HashSet<>();
        for (Player player : Bukkit.getOnlinePlayers()) {
            UUID uuid = player.getUniqueId();
            online.add(uuid);

            if (player.isDead() || !player.isValid()) {
                removeDisplay(uuid);
                continue;
            }

            ItemStack held = player.getInventory().getItemInMainHand();
            if (held.getType() == Material.AIR || !bridge.isIllusionistWeapon(held)) {
                removeDisplay(uuid);
                continue;
            }

            String fingerprint = held.getType().name() + ":" + (held.hasItemMeta() ? held.getItemMeta().hashCode() : 0);
            OverheadEntry entry = displays.get(uuid);

            if (entry == null || entry.itemDisplay == null || !entry.itemDisplay.isValid() || !entry.itemFingerprint.equals(fingerprint)) {
                removeDisplay(uuid);
                entry = createOverheadEntry(player, held, fingerprint, scale, heightOffset);
                if (entry != null) {
                    displays.put(uuid, entry);
                }
                continue;
            }

            // Update posisi melayang & rotasi mulus di atas kepala player
            entry.angleDeg = (entry.angleDeg + rotSpeed) % 360f;
            double bob = Math.sin(Math.toRadians(entry.angleDeg * 2.0)) * 0.08;
            Location targetLoc = player.getLocation().add(0, heightOffset + bob, 0);
            targetLoc.setYaw(entry.angleDeg);
            targetLoc.setPitch(0f);

            entry.itemDisplay.teleport(targetLoc);
            if (entry.modelAnchor != null && entry.modelAnchor.isValid()) {
                entry.modelAnchor.teleport(targetLoc);
            }
        }

        for (UUID tracked : new HashSet<>(displays.keySet())) {
            if (!online.contains(tracked)) {
                removeDisplay(tracked);
            }
        }
    }

    private OverheadEntry createOverheadEntry(Player player, ItemStack held, String fingerprint, float scale, double heightOffset) {
        Location spawnLoc = player.getLocation().add(0, heightOffset, 0);
        ItemStack visualStack = held.clone();
        visualStack.setAmount(1);

        ItemDisplay itemDisplay = player.getWorld().spawn(spawnLoc, ItemDisplay.class, display -> {
            display.setItemStack(visualStack);
            display.setBillboard(Display.Billboard.FIXED);
            display.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.FIXED);
            display.setTeleportDuration(1);
            display.setBrightness(new Display.Brightness(15, 15));
            display.setTransformation(new Transformation(
                    new Vector3f(0f, 0f, 0f),
                    new AxisAngle4f(0f, 0f, 1f, 0f),
                    new Vector3f(scale, scale, scale),
                    new AxisAngle4f(0f, 0f, 1f, 0f)
            ));
        });

        Entity modelAnchor = null;
        String megBlueprint = plugin.getConfig().getString("overhead-display.modelengine-blueprint", "");
        if (megBlueprint != null && !megBlueprint.isEmpty()) {
            List<Entity> dummy = new ArrayList<>();
            modelAnchor = bridge.spawnModelEngineVfx(spawnLoc, megBlueprint, "", 20 * 600, dummy);
        }

        return new OverheadEntry(itemDisplay, modelAnchor, fingerprint);
    }

    public void removeDisplay(UUID uuid) {
        OverheadEntry entry = displays.remove(uuid);
        if (entry != null) {
            if (entry.itemDisplay != null && entry.itemDisplay.isValid()) {
                entry.itemDisplay.remove();
            }
            if (entry.modelAnchor != null && entry.modelAnchor.isValid()) {
                entry.modelAnchor.remove();
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        removeDisplay(event.getPlayer().getUniqueId());
    }

    public void cleanupAll() {
        for (UUID uuid : new HashSet<>(displays.keySet())) {
            removeDisplay(uuid);
        }
    }
}
