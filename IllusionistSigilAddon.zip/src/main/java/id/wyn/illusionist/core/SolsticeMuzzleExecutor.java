package id.wyn.illusionist.core;

import id.wyn.illusionist.IllusionistSigilAddon;
import id.wyn.illusionist.hook.PluginBridgeManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.lang.reflect.Method;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class SolsticeMuzzleExecutor {

    private final IllusionistSigilAddon plugin;
    private final PluginBridgeManager bridge;
    private final OverheadWeaponManager overheadManager;
    private final MiniMessage mm = MiniMessage.miniMessage();

    private static final class ChantSession {
        int currentTicks;
        final int maxTicks;
        final double baseDamage;
        final double radius;
        final int fieldDurationTicks;
        TextDisplay hologram;
        Entity circleAnchor;

        ChantSession(int maxTicks, double baseDamage, double radius, int fieldDurationTicks) {
            this.currentTicks = 0;
            this.maxTicks = Math.max(1, maxTicks);
            this.baseDamage = baseDamage;
            this.radius = radius;
            this.fieldDurationTicks = fieldDurationTicks;
        }
    }

    private static final class PostChantState {
        final int cardSlot;
        final ItemStack cardItem;
        final int weaponSlot;
        final ItemStack weaponItem;
        final ItemStack[] savedStorageContents;
        final ItemStack[] savedArmorContents;
        final ItemStack savedOffhand;
        final boolean inventoryCleared;

        PostChantState(int cardSlot, ItemStack cardItem, int weaponSlot, ItemStack weaponItem,
                       ItemStack[] savedStorageContents, ItemStack[] savedArmorContents,
                       ItemStack savedOffhand, boolean inventoryCleared) {
            this.cardSlot = cardSlot;
            this.cardItem = cardItem != null ? cardItem.clone() : null;
            this.weaponSlot = weaponSlot;
            this.weaponItem = weaponItem != null ? weaponItem.clone() : null;
            this.savedStorageContents = cloneItemArray(savedStorageContents);
            this.savedArmorContents = cloneItemArray(savedArmorContents);
            this.savedOffhand = savedOffhand != null ? savedOffhand.clone() : null;
            this.inventoryCleared = inventoryCleared;
        }

        private static ItemStack[] cloneItemArray(ItemStack[] arr) {
            if (arr == null) return null;
            ItemStack[] copy = new ItemStack[arr.length];
            for (int i = 0; i < arr.length; i++) {
                copy[i] = arr[i] != null ? arr[i].clone() : null;
            }
            return copy;
        }
    }

    private final Map<UUID, ChantSession> activeSessions = new ConcurrentHashMap<>();
    private final Map<UUID, PostChantState> postChantStates = new ConcurrentHashMap<>();
    private final Map<UUID, GameMode> fallbackSpectatorModes = new ConcurrentHashMap<>();
    private final Set<UUID> packetCameraUsers = ConcurrentHashMap.newKeySet();
    private final Map<UUID, Entity> cameraAnchors = new ConcurrentHashMap<>();
    private final List<Entity> spawnedVfxEntities = Collections.synchronizedList(new ArrayList<>());

    private final Particle.DustOptions goldDust = new Particle.DustOptions(Color.fromRGB(245, 197, 66), 1.4f);
    private final Particle.DustOptions creamDust = new Particle.DustOptions(Color.fromRGB(255, 244, 214), 1.2f);
    private final Particle.DustOptions cyanDust = new Particle.DustOptions(Color.fromRGB(78, 242, 210), 1.15f);
    private final Particle.DustOptions emeraldDust = new Particle.DustOptions(Color.fromRGB(85, 255, 85), 1.3f);

    public SolsticeMuzzleExecutor(IllusionistSigilAddon plugin, PluginBridgeManager bridge, OverheadWeaponManager overheadManager) {
        this.plugin = plugin;
        this.bridge = bridge;
        this.overheadManager = overheadManager;
    }

    public boolean isChanting(Player player) {
        return activeSessions.containsKey(player.getUniqueId());
    }

    public boolean isPostChantActive(Player player) {
        return postChantStates.containsKey(player.getUniqueId());
    }

    public void castSolsticeMuzzle(Player caster, double baseDamage, double radius, int fieldDurationTicks) {
        UUID uuid = caster.getUniqueId();
        if (activeSessions.containsKey(uuid)) return;

        overheadManager.clearHiddenAfterChant(uuid);
        postChantStates.remove(uuid);

        World world = caster.getWorld();
        Location origin = caster.getLocation().clone();
        int chantTicks = plugin.getConfig().getInt("skill.chant-ticks", 30);

        ChantSession session = new ChantSession(chantTicks, baseDamage, radius, fieldDurationTicks);
        activeSessions.put(uuid, session);

        bridge.castMythicSkill(caster, plugin.getConfig().getString("hooks.mythicmobs.on-chant-skill", "Illusionist_SolsticeMuzzle_Chant"));

        world.playSound(origin, Sound.ENTITY_ILLUSIONER_PREPARE_MIRROR, 1.2f, 0.85f);
        world.playSound(origin, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.35f);

        session.hologram = spawnChantHologram(caster);
        session.circleAnchor = bridge.spawnModelEngineVfx(
                origin,
                plugin.getConfig().getString("hooks.modelengine.chant-circle-blueprint", "fx_solstice_muzzle_circle"),
                plugin.getConfig().getString("hooks.modelengine.fallback-blueprint", "fx_card_orbital"),
                chantTicks + 15,
                spawnedVfxEntities
        );

        if (plugin.getConfig().getBoolean("cinematic.enabled", true)) {
            startCinematicCamera(caster, origin);
        }

        new BukkitRunnable() {
            @Override
            public void run() {
                ChantSession current = activeSessions.get(uuid);
                if (current == null || !caster.isOnline() || caster.isDead()) {
                    cleanupSession(caster);
                    cancel();
                    return;
                }

                if (current.currentTicks == 1) {
                    Entity cam = cameraAnchors.get(uuid);
                    if (cam != null && cam.isValid()) {
                        cam.teleport(cam.getLocation());
                    }
                }
                if (current.currentTicks % 10 == 0) {
                    caster.swingMainHand();
                }

                if (current.hologram != null && current.hologram.isValid()) {
                    current.hologram.teleport(caster.getLocation().add(0, 2.25, 0));
                }

                double progress = (double) current.currentTicks / current.maxTicks;
                updateChantHologram(current, progress);
                renderChantCircle(caster.getLocation(), progress);

                if (current.currentTicks >= current.maxTicks) {
                    cleanupSession(caster);
                    releaseSolsticeMuzzle(caster, current.baseDamage, current.radius, current.fieldDurationTicks);
                    cancel();
                    return;
                }
                current.currentTicks++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void releaseSolsticeMuzzle(Player caster, double baseDamage, double radius, int fieldDurationTicks) {
        UUID uuid = caster.getUniqueId();
        World world = caster.getWorld();
        Location eyeLoc = caster.getEyeLocation();

        PlayerInventory inv = caster.getInventory();
        int cardSlot = inv.getHeldItemSlot();
        ItemStack heldBeforeSwap = inv.getItemInMainHand();
        ItemStack cardItem = (heldBeforeSwap != null && heldBeforeSwap.getType() != Material.AIR && bridge.isIllusionistTriggerItem(heldBeforeSwap))
                ? heldBeforeSwap.clone()
                : null;

        ItemStack[] snapshotStorage = inv.getStorageContents();
        ItemStack[] snapshotArmor = inv.getArmorContents();
        ItemStack snapshotOffhand = inv.getItemInOffHand();

        // Hilangkan kartu display di atas kepala setelah chant selesai
        overheadManager.markHiddenAfterChant(uuid);

        // Tukar ke pistol / senjata utama sambil mempertahankan HUD hotbar custom
        int switchedWeaponSlot = swapToBattleWeapon(caster);
        int activeWeaponSlot = switchedWeaponSlot != -1 ? switchedWeaponSlot : inv.getHeldItemSlot();
        ItemStack activeWeaponItem = inv.getItem(activeWeaponSlot);

        boolean clearAfterChant = plugin.getConfig().getBoolean("post-chant-inventory.clear-inventory-after-chant", false);
        if (clearAfterChant) {
            clearInventoryExceptActiveWeapon(inv, activeWeaponSlot, activeWeaponItem);
        }

        postChantStates.put(uuid, new PostChantState(
                cardSlot,
                cardItem,
                activeWeaponSlot,
                activeWeaponItem,
                snapshotStorage,
                snapshotArmor,
                snapshotOffhand,
                clearAfterChant
        ));

        RayTraceResult ray = world.rayTraceBlocks(eyeLoc, eyeLoc.getDirection(), 14.0, FluidCollisionMode.NEVER, true);
        Location targetLoc = (ray != null && ray.getHitPosition() != null)
                ? ray.getHitPosition().toLocation(world)
                : eyeLoc.clone().add(eyeLoc.getDirection().multiply(9.0));
        targetLoc.setY(getGroundY(targetLoc));

        Title title = Title.title(
                mm.deserialize(plugin.getConfig().getString("visuals.title", "<gradient:#FFF4D6:#F5C542>Solstice Muzzle</gradient>")),
                mm.deserialize(plugin.getConfig().getString("visuals.subtitle", "<#D8C8A8>- SOLSTICE MUZZLE CHANT -</#D8C8A8>")),
                Title.Times.times(Duration.ofMillis(150), Duration.ofMillis(1400), Duration.ofMillis(400))
        );
        caster.showTitle(title);

        String glyphName = plugin.getConfig().getString("hooks.itemsadder.battle-hud-glyph", "illusionist:battle_mode_banner");
        String iaBanner = bridge.parseItemsAdderGlyph(glyphName);
        if (iaBanner != null) {
            caster.sendActionBar(Component.text(iaBanner));
        } else {
            caster.sendActionBar(mm.deserialize(plugin.getConfig().getString("visuals.battle-mode-text", "<#FFD06C>Battle Mode: <gradient:#FF5555:#FFD06C>Doomblaster</gradient> Equipped!</#FFD06C>")));
        }

        world.playSound(targetLoc, Sound.ENTITY_WARDEN_SONIC_BOOM, 0.8f, 1.4f);
        world.playSound(targetLoc, Sound.ENTITY_ILLUSIONER_CAST_SPELL, 1.3f, 0.9f);

        Location surgeLoc = caster.getLocation().clone();
        Vector direction = targetLoc.toVector().subtract(surgeLoc.toVector());
        if (direction.lengthSquared() > 0.01) {
            surgeLoc.setDirection(direction.normalize());
        }
        bridge.spawnModelEngineVfx(
                surgeLoc,
                plugin.getConfig().getString("hooks.modelengine.release-surge-blueprint", "fx_solstice_muzzle_surge"),
                plugin.getConfig().getString("hooks.modelengine.fallback-blueprint", "fx_card_throw"),
                45,
                spawnedVfxEntities
        );

        spawnReleaseBurst(caster.getLocation().add(0, 1.2, 0), targetLoc);
        bridge.castMythicSkill(caster, plugin.getConfig().getString("hooks.mythicmobs.on-release-skill", "Illusionist_SolsticeMuzzle_Release"));

        startLingeringMuzzleField(caster, targetLoc, baseDamage, radius, fieldDurationTicks);
    }

    private void clearInventoryExceptActiveWeapon(PlayerInventory inv, int activeSlot, ItemStack activeWeapon) {
        ItemStack keptWeapon = (activeWeapon != null && activeWeapon.getType() != Material.AIR)
                ? activeWeapon.clone()
                : null;
        inv.clear();
        inv.setArmorContents(new ItemStack[4]);
        inv.setItemInOffHand(null);
        if (keptWeapon != null && activeSlot >= 0 && activeSlot < inv.getSize()) {
            inv.setItem(activeSlot, keptWeapon);
            if (activeSlot >= 0 && activeSlot <= 8) {
                inv.setHeldItemSlot(activeSlot);
            }
        }
    }

    public void deactivateChantModeByPistol(Player player) {
        UUID uuid = player.getUniqueId();
        PostChantState state = postChantStates.remove(uuid);
        overheadManager.clearHiddenAfterChant(uuid);
        overheadManager.removeDisplay(uuid);

        PlayerInventory inv = player.getInventory();
        boolean restoreInv = plugin.getConfig().getBoolean("post-chant-inventory.restore-inventory-on-deactivate", true);

        if (state != null) {
            if (restoreInv && state.inventoryCleared && state.savedStorageContents != null) {
                inv.setStorageContents(PostChantState.cloneItemArray(state.savedStorageContents));
                if (state.savedArmorContents != null) {
                    inv.setArmorContents(PostChantState.cloneItemArray(state.savedArmorContents));
                }
                inv.setItemInOffHand(state.savedOffhand != null ? state.savedOffhand.clone() : null);
            }

            if (state.cardItem != null && state.cardItem.getType() != Material.AIR) {
                ItemStack existingAtCardSlot = inv.getItem(state.cardSlot);
                if (existingAtCardSlot == null || existingAtCardSlot.getType() == Material.AIR || bridge.isIllusionistTriggerItem(existingAtCardSlot)) {
                    inv.setItem(state.cardSlot, state.cardItem);
                } else if (!inv.containsAtLeast(state.cardItem, 1)) {
                    inv.addItem(state.cardItem);
                }
            }
            if (state.cardSlot >= 0 && state.cardSlot <= 8) {
                inv.setHeldItemSlot(state.cardSlot);
            }
        } else {
            for (int i = 0; i < 9; i++) {
                ItemStack item = inv.getItem(i);
                if (bridge.isIllusionistTriggerItem(item)) {
                    inv.setHeldItemSlot(i);
                    break;
                }
            }
        }

        Location loc = player.getLocation();
        player.getWorld().playSound(loc, Sound.BLOCK_BEACON_DEACTIVATE, 1.0f, 1.15f);
        player.getWorld().spawnParticle(Particle.DUST, loc.clone().add(0, 1.1, 0), 10, 0.3, 0.3, 0.3, 0, cyanDust);

        String msg = plugin.getConfig().getString(
                "weapon-swap.pistol-right-click-deactivate.deactivate-text",
                "<#F5C542>Solstice Muzzle Deactivated <gray>— Returned to Illusionist Card</gray></#F5C542>"
        );
        player.sendActionBar(mm.deserialize(msg));
    }

    private int swapToBattleWeapon(Player caster) {
        if (!plugin.getConfig().getBoolean("weapon-swap.enabled", true)) return -1;

        PlayerInventory inv = caster.getInventory();
        int currentSlot = inv.getHeldItemSlot();
        String mode = plugin.getConfig().getString("weapon-swap.mode", "AUTO").toUpperCase(Locale.ROOT);

        List<String> preferredIds = plugin.getConfig().getStringList("weapon-swap.preferred-weapons");
        List<String> preferredNames = plugin.getConfig().getStringList("weapon-swap.preferred-names");
        List<Integer> preferredCmds = plugin.getConfig().getIntegerList("weapon-swap.preferred-custom-model-data");

        if ("SLOT".equals(mode)) {
            int fixed = plugin.getConfig().getInt("weapon-swap.fixed-slot", 1) - 1;
            if (fixed >= 0 && fixed <= 8 && fixed != currentSlot) {
                inv.setHeldItemSlot(fixed);
                playSwapEffects(caster);
                return fixed;
            }
        }

        for (int i = 0; i < 9; i++) {
            if (i == currentSlot) continue;
            ItemStack item = inv.getItem(i);
            if (bridge.isPreferredBattleWeapon(item, preferredIds, preferredNames, preferredCmds)) {
                inv.setHeldItemSlot(i);
                playSwapEffects(caster);
                return i;
            }
        }

        ItemStack offhand = inv.getItemInOffHand();
        if (bridge.isPreferredBattleWeapon(offhand, preferredIds, preferredNames, preferredCmds)) {
            ItemStack main = inv.getItemInMainHand();
            inv.setItemInMainHand(offhand);
            inv.setItemInOffHand(main);
            playSwapEffects(caster);
            return currentSlot;
        }

        if (plugin.getConfig().getBoolean("weapon-swap.search-main-inventory", true)) {
            for (int i = 9; i < inv.getSize(); i++) {
                ItemStack item = inv.getItem(i);
                if (bridge.isPreferredBattleWeapon(item, preferredIds, preferredNames, preferredCmds)) {
                    int emptyHotbar = -1;
                    for (int h = 0; h < 9; h++) {
                        ItemStack hotItem = inv.getItem(h);
                        if (hotItem == null || hotItem.getType() == Material.AIR) {
                            emptyHotbar = h;
                            break;
                        }
                    }
                    if (emptyHotbar != -1) {
                        inv.setItem(emptyHotbar, item);
                        inv.setItem(i, null);
                        inv.setHeldItemSlot(emptyHotbar);
                        playSwapEffects(caster);
                        return emptyHotbar;
                    } else {
                        ItemStack currentCard = inv.getItem(currentSlot);
                        inv.setItem(currentSlot, item);
                        inv.setItem(i, currentCard);
                        playSwapEffects(caster);
                        return currentSlot;
                    }
                }
            }
        }

        if (plugin.getConfig().getBoolean("weapon-swap.fallback-to-other-hotbar-weapon", true)) {
            for (int i = 0; i < 9; i++) {
                if (i == currentSlot) continue;
                ItemStack item = inv.getItem(i);
                if (item == null || item.getType() == Material.AIR) continue;
                if (!bridge.isIllusionistTriggerItem(item) && bridge.isBattleWeaponItem(item)) {
                    inv.setHeldItemSlot(i);
                    playSwapEffects(caster);
                    return i;
                }
            }

            for (int offset = 1; offset < 9; offset++) {
                int idx = (currentSlot + offset) % 9;
                ItemStack item = inv.getItem(idx);
                if (item != null && item.getType() != Material.AIR) {
                    inv.setHeldItemSlot(idx);
                    playSwapEffects(caster);
                    return idx;
                }
            }
        }

        if (plugin.getConfig().getBoolean("weapon-swap.swap-offhand-fallback", true)) {
            ItemStack main = inv.getItemInMainHand();
            if (offhand.getType() != Material.AIR) {
                inv.setItemInMainHand(offhand);
                inv.setItemInOffHand(main);
                playSwapEffects(caster);
                return currentSlot;
            }
        }

        return -1;
    }

    private void playSwapEffects(Player caster) {
        Location loc = caster.getLocation();
        World world = caster.getWorld();

        String customSound = plugin.getConfig().getString("weapon-swap.swap-custom-sound", "awakened_gunslinger_sounds:samus.awakened_gunslinger.spin_pistol");
        if (customSound != null && !customSound.isEmpty()) {
            caster.playSound(loc, customSound, SoundCategory.PLAYERS, 1.0f, 1.0f);
        }
        world.playSound(loc, Sound.ITEM_ARMOR_EQUIP_DIAMOND, 1.0f, 1.3f);
        world.spawnParticle(Particle.DUST, loc.clone().add(0, 1.1, 0), 12, 0.35, 0.35, 0.35, 0, goldDust);
        world.spawnParticle(Particle.FLAME, loc.clone().add(0, 1.1, 0), 8, 0.25, 0.25, 0.25, 0.03);
    }

    private void startLingeringMuzzleField(Player caster, Location center, double baseDamage, double radius, int durationTicks) {
        World world = center.getWorld();

        new BukkitRunnable() {
            int elapsed = 0;

            @Override
            public void run() {
                if (elapsed >= durationTicks || !caster.isOnline()) {
                    cancel();
                    return;
                }

                for (int i = 0; i < 18; i++) {
                    double angle = Math.random() * Math.PI * 2;
                    double dist = Math.random() * radius;
                    double x = center.getX() + Math.cos(angle) * dist;
                    double z = center.getZ() + Math.sin(angle) * dist;
                    double y = center.getY() + 0.15 + (Math.random() * 0.6);

                    world.spawnParticle(Particle.END_ROD, x, y, z, 1, 0.05, 0.12, 0.05, 0.01);
                    world.spawnParticle(Particle.DUST, x, y, z, 1, 0.1, 0.1, 0.1, 0, goldDust);
                    if (i % 4 == 0) {
                        world.spawnParticle(Particle.SQUID_INK, x, y + 0.2, z, 1, 0.08, 0.15, 0.08, 0.01);
                    }
                }

                if (elapsed % 15 == 0) {
                    double scaledDamage = bridge.computeMythicLibMagicDamage(caster, baseDamage * 0.35);
                    for (Entity entity : world.getNearbyEntities(center, radius, 3.0, radius)) {
                        if (!(entity instanceof LivingEntity target) || target.getUniqueId().equals(caster.getUniqueId())) {
                            continue;
                        }
                        if (target instanceof ArmorStand) continue;

                        Vector pull = center.toVector().subtract(target.getLocation().toVector());
                        if (pull.lengthSquared() > 0.25) {
                            target.setVelocity(pull.normalize().multiply(0.35).setY(0.05));
                        }

                        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 25, 4, false, false, true));
                        target.damage(scaledDamage, caster);
                    }
                }

                elapsed += 2;
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    private void renderChantCircle(Location loc, double progress) {
        World world = loc.getWorld();
        int maxPoints = 36;
        int currentPoints = (int) (maxPoints * Math.min(1.0, progress));

        for (int i = 0; i < currentPoints; i++) {
            double angle = (2 * Math.PI * i) / maxPoints;
            double x = Math.cos(angle) * 1.35;
            double y = Math.sin(angle) * 1.35 + 1.25;
            Vector offset = new Vector(x, y, 0);
            rotateAroundY(offset, -Math.toRadians(loc.getYaw()));
            world.spawnParticle(Particle.DUST, loc.clone().add(offset), 1, 0, 0, 0, 0, cyanDust);
        }

        for (int i = 0; i < 12; i++) {
            double angle = (2 * Math.PI * i) / 12 + (progress * Math.PI * 2);
            double gx = loc.getX() + Math.cos(angle) * 2.1;
            double gz = loc.getZ() + Math.sin(angle) * 2.1;
            world.spawnParticle(Particle.DUST, gx, loc.getY() + 0.1, gz, 1, 0.05, 0.02, 0.05, 0, goldDust);
            if (i % 3 == 0) {
                world.spawnParticle(Particle.SQUID_INK, gx, loc.getY() + 0.25, gz, 1, 0.05, 0.1, 0.05, 0.01);
            }
        }
    }

    private void spawnReleaseBurst(Location start, Location end) {
        World world = start.getWorld();
        Vector dir = end.toVector().subtract(start.toVector());
        double length = dir.length();
        if (length < 0.01) return;
        Vector step = dir.normalize().multiply(0.5);

        Location current = start.clone();
        for (double d = 0; d < length; d += 0.5) {
            world.spawnParticle(Particle.DUST, current, 3, 0.4, 0.4, 0.4, 0, goldDust);
            world.spawnParticle(Particle.DUST, current, 2, 0.35, 0.35, 0.35, 0, creamDust);
            world.spawnParticle(Particle.DUST, current, 2, 0.45, 0.45, 0.45, 0, emeraldDust);
            world.spawnParticle(Particle.SQUID_INK, current, 1, 0.3, 0.3, 0.3, 0.02);
            current.add(step);
        }
    }

    private TextDisplay spawnChantHologram(Player caster) {
        return caster.getWorld().spawn(caster.getLocation().add(0, 2.25, 0), TextDisplay.class, display -> {
            display.text(mm.deserialize("<#FFF4D6>✦ FAST CHANT ✦</#FFF4D6>\n<#F5C542>Solstice Muzzle Sigil</#F5C542>"));
            display.setBillboard(Display.Billboard.CENTER);
            display.setBackgroundColor(Color.fromARGB(110, 30, 24, 16));
            display.setSeeThrough(true);
            display.setTeleportDuration(1);
            spawnedVfxEntities.add(display);
        });
    }

    private void updateChantHologram(ChantSession session, double progress) {
        if (session.hologram == null || !session.hologram.isValid()) return;
        int pct = (int) Math.min(100, Math.round(progress * 100));
        int filled = (int) Math.round(progress * 10);
        String bar = "█".repeat(Math.max(0, filled)) + "░".repeat(Math.max(0, 10 - filled));
        session.hologram.text(mm.deserialize(
                "<#FFF4D6>✦ FAST CHANT " + pct + "% ✦</#FFF4D6>\n" +
                "<#F5C542>[" + bar + "]</#F5C542>"
        ));
    }

    private void startCinematicCamera(Player caster, Location origin) {
        double dist = plugin.getConfig().getDouble("cinematic.camera-distance", 3.8);
        double height = plugin.getConfig().getDouble("cinematic.camera-height", 1.65);

        Vector backward = origin.getDirection().setY(0).normalize().multiply(-dist).add(new Vector(0, height, 0));
        Location camLoc = origin.clone().add(backward);
        camLoc.setDirection(origin.clone().add(0, 1.25, 0).toVector().subtract(camLoc.toVector()));

        Interaction camAnchor = origin.getWorld().spawn(camLoc, Interaction.class, entity -> {
            entity.setInteractionWidth(0.0f);
            entity.setInteractionHeight(0.0f);
            entity.setResponsive(false);
            entity.setInvulnerable(true);
            entity.setRotation(camLoc.getYaw(), camLoc.getPitch());
        });
        spawnedVfxEntities.add(camAnchor);
        cameraAnchors.put(caster.getUniqueId(), camAnchor);

        if (sendCameraPacket(caster, camAnchor)) {
            packetCameraUsers.add(caster.getUniqueId());
        } else {
            fallbackSpectatorModes.put(caster.getUniqueId(), caster.getGameMode());
            caster.setGameMode(GameMode.SPECTATOR);
            caster.setSpectatorTarget(camAnchor);
        }
    }

    public void skipCinematic(Player caster) {
        UUID uuid = caster.getUniqueId();
        if (packetCameraUsers.remove(uuid)) {
            sendCameraPacket(caster, caster);
        }
        if (fallbackSpectatorModes.containsKey(uuid)) {
            GameMode prev = fallbackSpectatorModes.remove(uuid);
            caster.setSpectatorTarget(null);
            caster.setGameMode(prev);
        }
        Entity cam = cameraAnchors.remove(uuid);
        if (cam != null && cam.isValid()) {
            cam.remove();
            spawnedVfxEntities.remove(cam);
        }
    }

    private boolean sendCameraPacket(Player viewer, Entity target) {
        try {
            Object serverPlayer = viewer.getClass().getMethod("getHandle").invoke(viewer);
            Object nmsTarget = target.getClass().getMethod("getHandle").invoke(target);

            Class<?> packetClass = Class.forName("net.minecraft.network.protocol.game.ClientboundSetCameraPacket");
            Class<?> nmsEntityClass = Class.forName("net.minecraft.world.entity.Entity");
            Object packet = packetClass.getConstructor(nmsEntityClass).newInstance(nmsTarget);

            Object connection = serverPlayer.getClass().getField("connection").get(serverPlayer);
            Class<?> basePacketClass = Class.forName("net.minecraft.network.protocol.Packet");

            Method sendMethod = null;
            for (Method m : connection.getClass().getMethods()) {
                if (m.getName().equals("send") && m.getParameterCount() == 1
                        && m.getParameterTypes()[0].isAssignableFrom(basePacketClass)) {
                    sendMethod = m;
                    break;
                }
            }
            if (sendMethod == null) return false;
            sendMethod.invoke(connection, packet);
            return true;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private void cleanupSession(Player caster) {
        ChantSession session = activeSessions.remove(caster.getUniqueId());
        skipCinematic(caster);
        if (session != null) {
            if (session.hologram != null && session.hologram.isValid()) {
                session.hologram.remove();
                spawnedVfxEntities.remove(session.hologram);
            }
            if (session.circleAnchor != null && session.circleAnchor.isValid()) {
                session.circleAnchor.remove();
                spawnedVfxEntities.remove(session.circleAnchor);
            }
        }
    }

    public void cleanupPlayer(Player caster) {
        UUID uuid = caster.getUniqueId();
        PostChantState state = postChantStates.remove(uuid);
        if (state != null && state.inventoryCleared && state.savedStorageContents != null) {
            PlayerInventory inv = caster.getInventory();
            inv.setStorageContents(PostChantState.cloneItemArray(state.savedStorageContents));
            if (state.savedArmorContents != null) {
                inv.setArmorContents(PostChantState.cloneItemArray(state.savedArmorContents));
            }
            inv.setItemInOffHand(state.savedOffhand != null ? state.savedOffhand.clone() : null);
        }
        overheadManager.clearHiddenAfterChant(uuid);
        overheadManager.removeDisplay(uuid);
        cleanupSession(caster);
    }

    public void cleanupAll() {
        for (UUID uuid : new HashSet<>(packetCameraUsers)) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) skipCinematic(p);
        }
        for (UUID uuid : new HashSet<>(fallbackSpectatorModes.keySet())) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) skipCinematic(p);
        }
        for (Map.Entry<UUID, PostChantState> entry : postChantStates.entrySet()) {
            Player p = Bukkit.getPlayer(entry.getKey());
            PostChantState state = entry.getValue();
            if (p != null && state != null && state.inventoryCleared && state.savedStorageContents != null) {
                PlayerInventory inv = p.getInventory();
                inv.setStorageContents(PostChantState.cloneItemArray(state.savedStorageContents));
                if (state.savedArmorContents != null) {
                    inv.setArmorContents(PostChantState.cloneItemArray(state.savedArmorContents));
                }
                inv.setItemInOffHand(state.savedOffhand != null ? state.savedOffhand.clone() : null);
            }
        }
        activeSessions.clear();
        postChantStates.clear();
        synchronized (spawnedVfxEntities) {
            for (Entity e : spawnedVfxEntities) {
                if (e != null && e.isValid()) e.remove();
            }
            spawnedVfxEntities.clear();
        }
    }

    private double getGroundY(Location loc) {
        Location check = loc.clone();
        for (int i = 0; i < 6; i++) {
            if (check.getBlock().getType().isSolid()) {
                return check.getBlockY() + 1.0;
            }
            check.subtract(0, 1, 0);
        }
        return loc.getY();
    }

    private void rotateAroundY(Vector v, double angle) {
        double cos = Math.cos(angle);
        double sin = Math.sin(angle);
        double x = v.getX() * cos + v.getZ() * sin;
        double z = -v.getX() * sin + v.getZ() * cos;
        v.setX(x).setZ(z);
    }
}
