package id.wyn.illusionist.core;

import id.wyn.illusionist.IllusionistSigilAddon;
import id.wyn.illusionist.hook.PluginBridgeManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class GenesisGripExecutor {

    private final IllusionistSigilAddon plugin;
    private final PluginBridgeManager bridge;
    private final MiniMessage mm = MiniMessage.miniMessage();

    private final Set<UUID> activeCasters = ConcurrentHashMap.newKeySet();
    private final Map<UUID, GameMode> previousGameModes = new ConcurrentHashMap<>();
    private final Map<UUID, Entity> cameraAnchors = new ConcurrentHashMap<>();
    private final List<Entity> spawnedVfxEntities = Collections.synchronizedList(new ArrayList<>());

    private final Particle.DustOptions goldDust = new Particle.DustOptions(Color.fromRGB(245, 197, 66), 1.4f);
    private final Particle.DustOptions creamDust = new Particle.DustOptions(Color.fromRGB(255, 244, 214), 1.2f);
    private final Particle.DustOptions cyanDust = new Particle.DustOptions(Color.fromRGB(78, 242, 210), 1.1f);
    private final Particle.DustOptions emeraldDust = new Particle.DustOptions(Color.fromRGB(85, 255, 85), 1.3f);

    public GenesisGripExecutor(IllusionistSigilAddon plugin, PluginBridgeManager bridge) {
        this.plugin = plugin;
        this.bridge = bridge;
    }

    public void castGenesisGrip(Player caster, double baseDamage, double radius, int fieldDurationTicks) {
        if (activeCasters.contains(caster.getUniqueId())) return;
        activeCasters.add(caster.getUniqueId());

        World world = caster.getWorld();
        Location origin = caster.getLocation().clone();
        int chantTicks = plugin.getConfig().getInt("skill.chant-ticks", 30);

        bridge.castMythicSkill(caster, plugin.getConfig().getString("hooks.mythicmobs.on-chant-skill", "Illusionist_GenesisGrip_Chant"));

        world.playSound(origin, Sound.ENTITY_ILLUSIONER_PREPARE_MIRROR, 1.2f, 0.85f);
        world.playSound(origin, Sound.BLOCK_BEACON_ACTIVATE, 1.0f, 1.35f);

        TextDisplay chantHologram = spawnChantHologram(caster);
        Entity circleAnchor = bridge.spawnModelEngineVfx(
                origin,
                plugin.getConfig().getString("hooks.modelengine.chant-circle-blueprint", "fx_genesis_grip_circle"),
                plugin.getConfig().getString("hooks.modelengine.fallback-blueprint", "fx_card_orbital"),
                chantTicks + 15,
                spawnedVfxEntities
        );

        if (plugin.getConfig().getBoolean("cinematic.enabled", true)) {
            startCinematicCamera(caster, origin);
        }

        new BukkitRunnable() {
            int tick = 0;

            @Override
            public void run() {
                if (!caster.isOnline() || caster.isDead()) {
                    cleanupCaster(caster, chantHologram, circleAnchor);
                    cancel();
                    return;
                }

                if (chantHologram != null && chantHologram.isValid()) {
                    chantHologram.teleport(caster.getLocation().add(0, 2.45, 0));
                }

                double progress = (double) tick / chantTicks;
                renderChantCircle(caster.getLocation(), progress);

                if (tick >= chantTicks) {
                    cleanupCaster(caster, chantHologram, circleAnchor);
                    releaseGenesisGrip(caster, baseDamage, radius, fieldDurationTicks);
                    cancel();
                    return;
                }
                tick++;
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void releaseGenesisGrip(Player caster, double baseDamage, double radius, int fieldDurationTicks) {
        World world = caster.getWorld();
        Location eyeLoc = caster.getEyeLocation();

        RayTraceResult ray = world.rayTraceBlocks(eyeLoc, eyeLoc.getDirection(), 14.0, FluidCollisionMode.NEVER, true);
        Location targetLoc = (ray != null && ray.getHitPosition() != null)
                ? ray.getHitPosition().toLocation(world)
                : eyeLoc.clone().add(eyeLoc.getDirection().multiply(9.0));
        targetLoc.setY(getGroundY(targetLoc));

        Title title = Title.title(
                mm.deserialize(plugin.getConfig().getString("visuals.title", "<gradient:#FFF4D6:#F5C542>Genesis Grip</gradient>")),
                mm.deserialize(plugin.getConfig().getString("visuals.subtitle", "<#D8C8A8>- SCIURTA DIFFINDIS -</#D8C8A8>")),
                Title.Times.times(Duration.ofMillis(150), Duration.ofMillis(1400), Duration.ofMillis(400))
        );
        caster.showTitle(title);

        String glyphName = plugin.getConfig().getString("hooks.itemsadder.battle-hud-glyph", "illusionist:battle_mode_banner");
        String iaBanner = bridge.parseItemsAdderGlyph(glyphName);
        if (iaBanner != null) {
            caster.sendActionBar(Component.text(iaBanner));
        } else {
            caster.sendActionBar(mm.deserialize(plugin.getConfig().getString("visuals.battle-mode-text", "<#4EF2D2>Battle Mode Activated!</#4EF2D2>")));
        }

        world.playSound(targetLoc, Sound.ENTITY_WARDEN_SONIC_BOOM, 0.8f, 1.4f);
        world.playSound(targetLoc, Sound.ENTITY_ILLUSIONER_CAST_SPELL, 1.3f, 0.9f);

        Location surgeLoc = caster.getLocation().clone();
        Vector direction = targetLoc.toVector().subtract(surgeLoc.toVector());
        if (direction.lengthSquared() > 0.01) {
            surgeLoc.setDirection(direction.normalize());
        }
        bridge.spawnModelEngineVfx(
                surgeLoc,
                plugin.getConfig().getString("hooks.modelengine.release-surge-blueprint", "fx_genesis_grip_surge"),
                plugin.getConfig().getString("hooks.modelengine.fallback-blueprint", "fx_card_throw"),
                45,
                spawnedVfxEntities
        );

        spawnReleaseBurst(caster.getLocation().add(0, 1.2, 0), targetLoc);
        bridge.castMythicSkill(caster, plugin.getConfig().getString("hooks.mythicmobs.on-release-skill", "Illusionist_GenesisGrip_Release"));

        startLingeringGripField(caster, targetLoc, baseDamage, radius, fieldDurationTicks);
    }

    private void startLingeringGripField(Player caster, Location center, double baseDamage, double radius, int durationTicks) {
        World world = center.getWorld();

        new BukkitRunnable() {
            int elapsed = 0;

            @Override
            public void run() {
                if (elapsed >= durationTicks || !caster.isOnline()) {
                    cancel();
                    return;
                }

                for (int i = 0; i < 18; i++) {
                    double angle = Math.random() * Math.PI * 2;
                    double dist = Math.random() * radius;
                    double x = center.getX() + Math.cos(angle) * dist;
                    double z = center.getZ() + Math.sin(angle) * dist;
                    double y = center.getY() + 0.15 + (Math.random() * 0.6);

                    world.spawnParticle(Particle.END_ROD, x, y, z, 1, 0.05, 0.12, 0.05, 0.01);
                    world.spawnParticle(Particle.DUST, x, y, z, 1, 0.1, 0.1, 0.1, 0, goldDust);
                    if (i % 4 == 0) {
                        world.spawnParticle(Particle.SQUID_INK, x, y + 0.2, z, 1, 0.08, 0.15, 0.08, 0.01);
                    }
                }

                if (elapsed % 15 == 0) {
                    double scaledDamage = bridge.computeMythicLibMagicDamage(caster, baseDamage * 0.35);
                    for (Entity entity : world.getNearbyEntities(center, radius, 3.0, radius)) {
                        if (!(entity instanceof LivingEntity target) || target.getUniqueId().equals(caster.getUniqueId())) {
                            continue;
                        }
                        if (target instanceof ArmorStand) continue;

                        Vector pull = center.toVector().subtract(target.getLocation().toVector());
                        if (pull.lengthSquared() > 0.25) {
                            target.setVelocity(pull.normalize().multiply(0.35).setY(0.05));
                        }

                        target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 25, 4, false, false, true));
                        target.damage(scaledDamage, caster);
                    }
                }

                elapsed += 2;
            }
        }.runTaskTimer(plugin, 0L, 2L);
    }

    private void renderChantCircle(Location loc, double progress) {
        World world = loc.getWorld();
        int maxPoints = 36;
        int currentPoints = (int) (maxPoints * Math.min(1.0, progress));

        for (int i = 0; i < currentPoints; i++) {
            double angle = (2 * Math.PI * i) / maxPoints;
            double x = Math.cos(angle) * 1.35;
            double y = Math.sin(angle) * 1.35 + 1.25;
            Vector offset = new Vector(x, y, 0);
            rotateAroundY(offset, -Math.toRadians(loc.getYaw()));
            world.spawnParticle(Particle.DUST, loc.clone().add(offset), 1, 0, 0, 0, 0, cyanDust);
        }

        for (int i = 0; i < 12; i++) {
            double angle = (2 * Math.PI * i) / 12 + (progress * Math.PI * 2);
            double gx = loc.getX() + Math.cos(angle) * 2.1;
            double gz = loc.getZ() + Math.sin(angle) * 2.1;
            world.spawnParticle(Particle.DUST, gx, loc.getY() + 0.1, gz, 1, 0.05, 0.02, 0.05, 0, goldDust);
            if (i % 3 == 0) {
                world.spawnParticle(Particle.SQUID_INK, gx, loc.getY() + 0.25, gz, 1, 0.05, 0.1, 0.05, 0.01);
            }
        }
    }

    private void spawnReleaseBurst(Location start, Location end) {
        World world = start.getWorld();
        Vector dir = end.toVector().subtract(start.toVector());
        double length = dir.length();
        if (length < 0.01) return;
        Vector step = dir.normalize().multiply(0.5);

        Location current = start.clone();
        for (double d = 0; d < length; d += 0.5) {
            world.spawnParticle(Particle.DUST, current, 3, 0.4, 0.4, 0.4, 0, goldDust);
            world.spawnParticle(Particle.DUST, current, 2, 0.35, 0.35, 0.35, 0, creamDust);
            world.spawnParticle(Particle.DUST, current, 2, 0.45, 0.45, 0.45, 0, emeraldDust);
            world.spawnParticle(Particle.SQUID_INK, current, 1, 0.3, 0.3, 0.3, 0.02);
            current.add(step);
        }
    }

    private TextDisplay spawnChantHologram(Player caster) {
        return caster.getWorld().spawn(caster.getLocation().add(0, 2.45, 0), TextDisplay.class, display -> {
            display.text(mm.deserialize("<#FFF4D6>✦ FAST CHANT ✦</#FFF4D6>\n<#F5C542>Genesis Grip Sigil</#F5C542>"));
            display.setBillboard(Display.Billboard.CENTER);
            display.setBackgroundColor(Color.fromARGB(110, 30, 24, 16));
            display.setSeeThrough(true);
            spawnedVfxEntities.add(display);
        });
    }

    private void startCinematicCamera(Player caster, Location origin) {
        Vector backward = origin.getDirection().setY(0).normalize().multiply(-3.8).add(new Vector(0, 1.6, 0));
        Location camLoc = origin.clone().add(backward);
        camLoc.setDirection(origin.clone().add(0, 1.2, 0).toVector().subtract(camLoc.toVector()));

        ArmorStand camStand = origin.getWorld().spawn(camLoc, ArmorStand.class, stand -> {
            stand.setInvisible(true);
            stand.setGravity(false);
            stand.setMarker(true);
        });
        spawnedVfxEntities.add(camStand);
        cameraAnchors.put(caster.getUniqueId(), camStand);
        previousGameModes.put(caster.getUniqueId(), caster.getGameMode());

        caster.setGameMode(GameMode.SPECTATOR);
        caster.setSpectatorTarget(camStand);
    }

    public void skipCinematic(Player caster) {
        UUID uuid = caster.getUniqueId();
        if (previousGameModes.containsKey(uuid)) {
            GameMode prev = previousGameModes.remove(uuid);
            caster.setSpectatorTarget(null);
            caster.setGameMode(prev);
        }
        Entity cam = cameraAnchors.remove(uuid);
        if (cam != null && cam.isValid()) {
            cam.remove();
            spawnedVfxEntities.remove(cam);
        }
    }

    private void cleanupCaster(Player caster, Entity hologram, Entity modelAnchor) {
        activeCasters.remove(caster.getUniqueId());
        skipCinematic(caster);
        if (hologram != null && hologram.isValid()) {
            hologram.remove();
            spawnedVfxEntities.remove(hologram);
        }
        if (modelAnchor != null && modelAnchor.isValid()) {
            modelAnchor.remove();
            spawnedVfxEntities.remove(modelAnchor);
        }
    }

    public void cleanupAll() {
        for (UUID uuid : new HashSet<>(previousGameModes.keySet())) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) skipCinematic(p);
        }
        synchronized (spawnedVfxEntities) {
            for (Entity e : spawnedVfxEntities) {
                if (e != null && e.isValid()) e.remove();
            }
            spawnedVfxEntities.clear();
        }
    }

    private double getGroundY(Location loc) {
        Location check = loc.clone();
        for (int i = 0; i < 6; i++) {
            if (check.getBlock().getType().isSolid()) {
                return check.getBlockY() + 1.0;
            }
            check.subtract(0, 1, 0);
        }
        return loc.getY();
    }

    private void rotateAroundY(Vector v, double angle) {
        double cos = Math.cos(angle);
        double sin = Math.sin(angle);
        double x = v.getX() * cos + v.getZ() * sin;
        double z = -v.getX() * sin + v.getZ() * cos;
        v.setX(x).setZ(z);
    }
}
