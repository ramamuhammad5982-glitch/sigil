package id.wyn.illusionist.core;

import id.wyn.illusionist.IllusionistSigilAddon;
import id.wyn.illusionist.hook.PluginBridgeManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class WeaponSelectionGUI implements Listener {

    private final IllusionistSigilAddon plugin;
    private final PluginBridgeManager bridge;
    private final SolsticeMuzzleExecutor executor;
    private final MiniMessage mm = MiniMessage.miniMessage();

    private final Map<UUID, List<WeaponOption>> openMenus = new ConcurrentHashMap<>();
    private final Map<UUID, WeaponOption> selectedChoice = new ConcurrentHashMap<>();

    public static final class WeaponOption {
        public final String id;
        public final String label;
        public final String summonSpec;
        public final String mythicSkill;
        public final Material iconMaterial;
        public final int customModelData;

        public WeaponOption(String id, String label, String summonSpec, String mythicSkill, Material iconMaterial, int customModelData) {
            this.id = id;
            this.label = label;
            this.summonSpec = summonSpec;
            this.mythicSkill = mythicSkill;
            this.iconMaterial = iconMaterial;
            this.customModelData = customModelData;
        }
    }

    public WeaponSelectionGUI(IllusionistSigilAddon plugin, PluginBridgeManager bridge, SolsticeMuzzleExecutor executor) {
        this.plugin = plugin;
        this.bridge = bridge;
        this.executor = executor;
    }

    public List<WeaponOption> getConfiguredOptions() {
        List<WeaponOption> out = new ArrayList<>();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("weapon-selection.options");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                ConfigurationSection itemSec = sec.getConfigurationSection(key);
                if (itemSec == null) continue;
                String label = itemSec.getString("name", key);
                String summonSpec = itemSec.getString("summon-item", "AUTO");
                String skill = itemSec.getString("mythic-skill", "Piercing_Combo");
                String matName = itemSec.getString("icon-material", "PAPER").toUpperCase(Locale.ROOT);
                Material mat = Material.matchMaterial(matName);
                if (mat == null) mat = Material.PAPER;
                int cmd = itemSec.getInt("custom-model-data", 0);
                out.add(new WeaponOption(key, label, summonSpec, skill, mat, cmd));
            }
        }
        if (out.isEmpty()) {
            out.add(new WeaponOption("spirit_greataxe", "<gradient:#51d54e:#80f7fd>Spirit GreatAxe</gradient>",
                    "MMOITEMS:SWORD:SPIRITRPG", "Spirit_Strike", Material.STICK, 0));
            out.add(new WeaponOption("infernal_dominion", "<gradient:#7A0C0C:#B22222>Infernal Dominion</gradient>",
                    "MMOITEMS:SWORD:INFERNAL_DOMINION", "Infernal_Execution", Material.STICK, 100));
            out.add(new WeaponOption("kurayami_eclipse", "<gradient:#81adff:#a4f9ff>Kurayami Eclipse</gradient>",
                    "MMOITEMS:SWORD:KURAYAMI", "ArteonSTD_Sharp_Slice", Material.STICK, 1347));
            out.add(new WeaponOption("gauntlet_of_times", "<gradient:#E3DB46:#ECEf79>Gauntlet Of Times</gradient>",
                    "MMOITEMS:SWORD:GAUNTLET_OF_TIMES", "Eternal_Fist_Slash", Material.DIAMOND_SWORD, 70111));
        }
        return out;
    }

    public WeaponOption getSelectedOption(Player player) {
        return selectedChoice.get(player.getUniqueId());
    }

    public void openSelectionMenu(Player player) {
        List<WeaponOption> options = getConfiguredOptions();
        String titleRaw = plugin.getConfig().getString("weapon-selection.menu-title", "<#F5C542>Pilih Senjata / Mode Sigil</#F5C542>");
        int size = Math.max(9, Math.min(54, ((options.size() + 8) / 9) * 9));
        Inventory inv = Bukkit.createInventory(null, size, mm.deserialize(titleRaw));

        int slot = 0;
        for (WeaponOption opt : options) {
            if (slot >= size) break;
            ItemStack built = null;
            if (opt.summonSpec != null && !opt.summonSpec.isBlank() && !"AUTO".equalsIgnoreCase(opt.summonSpec)) {
                String prev = plugin.getConfig().getString("weapon-swap.summon-item", "AUTO");
                plugin.getConfig().set("weapon-swap.summon-item", opt.summonSpec);
                built = bridge.createSummonedPistol(
                        plugin.getConfig().getStringList("weapon-swap.preferred-weapons"),
                        plugin.getConfig().getIntegerList("weapon-swap.preferred-custom-model-data")
                );
                plugin.getConfig().set("weapon-swap.summon-item", prev);
            }
            ItemStack icon = (built != null && built.getType() != Material.AIR) ? built.clone() : new ItemStack(opt.iconMaterial);
            ItemMeta meta = icon.getItemMeta();
            if (meta != null) {
                meta.displayName(mm.deserialize(opt.label));
                if (opt.customModelData > 0 && built == null) {
                    meta.setCustomModelData(opt.customModelData);
                }
                List<Component> lore = new ArrayList<>();
                lore.add(mm.deserialize("<gray>Summon: <white>" + opt.summonSpec + "</white></gray>"));
                lore.add(mm.deserialize("<gray>Skill: <gold>" + opt.mythicSkill + "</gold></gray>"));
                lore.add(mm.deserialize("<yellow>Klik untuk memilih & memulai chant!</yellow>"));
                meta.lore(lore);
                icon.setItemMeta(meta);
            }
            inv.setItem(slot++, icon);
        }

        openMenus.put(player.getUniqueId(), options);
        player.openInventory(inv);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        List<WeaponOption> options = openMenus.get(player.getUniqueId());
        if (options == null) return;
        if (event.getView().getTopInventory() != event.getInventory()) return;

        event.setCancelled(true);
        int raw = event.getRawSlot();
        if (raw < 0 || raw >= options.size()) return;

        WeaponOption chosen = options.get(raw);
        selectedChoice.put(player.getUniqueId(), chosen);
        openMenus.remove(player.getUniqueId());
        player.closeInventory();

        // Apply chosen weapon & skill temporarily for this cast
        String prevSummon = plugin.getConfig().getString("weapon-swap.summon-item", "AUTO");
        String prevSkill = plugin.getConfig().getString("weapon-swap.pistol-skills.mythic-skill", "Piercing_Combo");
        plugin.getConfig().set("weapon-swap.summon-item", chosen.summonSpec);
        plugin.getConfig().set("weapon-swap.pistol-skills.mythic-skill", chosen.mythicSkill);

        executor.castSolsticeMuzzle(
                player,
                plugin.getConfig().getDouble("skill.base-damage", plugin.getConfig().getDouble("Skill.base-damage", 18.0)),
                plugin.getConfig().getDouble("skill.radius", plugin.getConfig().getDouble("Skill.radius", 4.5)),
                plugin.getConfig().getInt("skill.field-duration-ticks", plugin.getConfig().getInt("Skill.field-duration-ticks", 90))
        );

        // Restore defaults after triggering cast so other players/casts aren't permanently overwritten
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            plugin.getConfig().set("weapon-swap.summon-item", prevSummon);
            plugin.getConfig().set("weapon-swap.pistol-skills.mythic-skill", prevSkill);
        }, 5L);
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player player) {
            openMenus.remove(player.getUniqueId());
        }
    }
}
