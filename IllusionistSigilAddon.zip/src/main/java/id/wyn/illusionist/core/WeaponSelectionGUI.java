package id.wyn.illusionist.core;

import id.wyn.illusionist.IllusionistSigilAddon;
import id.wyn.illusionist.hook.PluginBridgeManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class WeaponSelectionGUI implements Listener {

    private final IllusionistSigilAddon plugin;
    private final PluginBridgeManager bridge;
    private final SolsticeMuzzleExecutor executor;
    private final MiniMessage mm = MiniMessage.miniMessage();

    private static final int SLOT_PREV = 18;
    private static final int SLOT_LEFT_PREVIEW = 12;
    private static final int SLOT_CENTER_FEATURE = 13;
    private static final int SLOT_RIGHT_PREVIEW = 14;
    private static final int SLOT_CONFIRM = 22;
    private static final int SLOT_NEXT = 26;

    private final Map<UUID, List<WeaponOption>> playerOptions = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> playerIndex = new ConcurrentHashMap<>();
    private final Map<UUID, WeaponOption> selectedChoice = new ConcurrentHashMap<>();

    public static final class WeaponOption {
        public final String id;
        public final String label;
        public final String summonSpec;
        public final String mythicSkill;
        public final Material iconMaterial;
        public final int customModelData;

        public WeaponOption(String id, String label, String summonSpec, String mythicSkill, Material iconMaterial, int customModelData) {
            this.id = id;
            this.label = label;
            this.summonSpec = summonSpec;
            this.mythicSkill = mythicSkill;
            this.iconMaterial = iconMaterial;
            this.customModelData = customModelData;
        }
    }

    public WeaponSelectionGUI(IllusionistSigilAddon plugin, PluginBridgeManager bridge, SolsticeMuzzleExecutor executor) {
        this.plugin = plugin;
        this.bridge = bridge;
        this.executor = executor;
    }

    public List<WeaponOption> getConfiguredOptions() {
        List<WeaponOption> out = new ArrayList<>();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("weapon-selection.options");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                ConfigurationSection itemSec = sec.getConfigurationSection(key);
                if (itemSec == null) continue;
                String label = itemSec.getString("name", key);
                String summonSpec = itemSec.getString("summon-item", "AUTO");
                String skill = itemSec.getString("mythic-skill", "");
                String matName = itemSec.getString("icon-material", "DIAMOND_SWORD").toUpperCase(Locale.ROOT);
                Material mat = Material.matchMaterial(matName);
                if (mat == null) mat = Material.DIAMOND_SWORD;
                int cmd = itemSec.getInt("custom-model-data", 0);
                out.add(new WeaponOption(key, label, summonSpec, skill, mat, cmd));
            }
        }
        if (out.isEmpty()) {
            out.add(new WeaponOption("doomblaster", "<gradient:#FF5555:#FFD06C>Doomblaster</gradient>",
                    "MMOITEMS:SWORD:AWAKENED_GUNSLINGER_DOOMBLASTER", "PIERCING_COMBO", Material.STONE_SWORD, 2095));
            out.add(new WeaponOption("spirit_greataxe", "<gradient:#51d54e:#80f7fd>Spirit GreatAxe</gradient>",
                    "MMOITEMS:SWORD:SPIRITRPG", "", Material.STICK, 88655));
            out.add(new WeaponOption("infernal_dominion", "<gradient:#7A0C0C:#B22222>Infernal Dominion</gradient>",
                    "MMOITEMS:SWORD:INFERNAL_DOMINION", "INFERNAL_EXECUTION", Material.STICK, 100));
            out.add(new WeaponOption("kurayami_eclipse", "<gradient:#81adff:#a4f9ff>Kurayami Eclipse</gradient>",
                    "MMOITEMS:SWORD:KURAYAMI", "KURAYAMI_SHARP_SLICE", Material.STICK, 1347));
            out.add(new WeaponOption("gauntlet_of_times", "<gradient:#E3DB46:#ECEf79>Gauntlet Of Times</gradient>",
                    "MMOITEMS:SWORD:GAUNTLET_OF_TIMES", "", Material.DIAMOND_SWORD, 70111));
            out.add(new WeaponOption("dio", "<gradient:#F5D042:#A855F7>Dio</gradient>",
                    "MMOITEMS:SWORD:DIO", "ETERNAL_FIST", Material.DIAMOND_SWORD, 0));
        }
        return out;
    }

    public WeaponOption getSelectedOption(Player player) {
        return selectedChoice.get(player.getUniqueId());
    }

    public void openSelectionMenu(Player player) {
        List<WeaponOption> options = getConfiguredOptions();
        if (options.isEmpty()) return;
        playerOptions.put(player.getUniqueId(), options);
        playerIndex.put(player.getUniqueId(), 0);
        renderCarousel(player, true);
    }

    private void renderCarousel(Player player, boolean createNewInv) {
        UUID uuid = player.getUniqueId();
        List<WeaponOption> options = playerOptions.get(uuid);
        if (options == null || options.isEmpty()) return;

        int idx = Math.floorMod(playerIndex.getOrDefault(uuid, 0), options.size());
        playerIndex.put(uuid, idx);

        String titleRaw = plugin.getConfig().getString(
                "weapon-selection.menu-title",
                "<#F5C542>Pilih Senjata Sigil <gray>(" + (idx + 1) + "/" + options.size() + ")</gray></#F5C542>"
        );
        String formattedTitle = titleRaw
                .replace("{index}", String.valueOf(idx + 1))
                .replace("{total}", String.valueOf(options.size()));

        Inventory inv = Bukkit.createInventory(null, 27, mm.deserialize(formattedTitle));

        ItemStack glass = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta glassMeta = glass.getItemMeta();
        if (glassMeta != null) {
            glassMeta.displayName(Component.empty());
            glass.setItemMeta(glassMeta);
        }
        for (int i = 0; i < 27; i++) {
            inv.setItem(i, glass);
        }

        int prevIdx = Math.floorMod(idx - 1, options.size());
        int nextIdx = Math.floorMod(idx + 1, options.size());

        inv.setItem(SLOT_LEFT_PREVIEW, buildOptionCardItem(options.get(prevIdx), false, prevIdx + 1, options.size()));
        inv.setItem(SLOT_CENTER_FEATURE, buildOptionCardItem(options.get(idx), true, idx + 1, options.size()));
        inv.setItem(SLOT_RIGHT_PREVIEW, buildOptionCardItem(options.get(nextIdx), false, nextIdx + 1, options.size()));

        inv.setItem(SLOT_PREV, buildNavButton(
                Material.ARROW,
                plugin.getConfig().getInt("weapon-selection.scroll-left-cmd", 0),
                "<#7B3FE4><bold>◀ Geser Kiri</bold></#7B3FE4>",
                "<gray>Klik untuk melihat senjata sebelumnya</gray>"
        ));
        int bgCmd = plugin.getConfig().getInt("weapon-selection.card-bg-cmd", 0);
        String bgMatName = plugin.getConfig().getString("weapon-selection.card-bg-material", "PURPLE_STAINED_GLASS_PANE").toUpperCase(Locale.ROOT);
        Material bgMat = Material.matchMaterial(bgMatName);
        if (bgMat == null) bgMat = Material.PURPLE_STAINED_GLASS_PANE;

        int[] backdropSlots = {3, 4, 5, 11, 15, 21, 23};
        for (int bSlot : backdropSlots) {
            ItemStack bgTile = new ItemStack(bgMat);
            ItemMeta bgMeta = bgTile.getItemMeta();
            if (bgMeta != null) {
                bgMeta.displayName(Component.empty());
                if (bgCmd > 0) {
                    bgMeta.setCustomModelData(bgCmd);
                }
                bgTile.setItemMeta(bgMeta);
            }
            inv.setItem(bSlot, bgTile);
        }

        inv.setItem(SLOT_CONFIRM, buildNavButton(
                Material.NETHER_STAR,
                plugin.getConfig().getInt("weapon-selection.confirm-cmd", 0),
                "<gold><bold>✦ PILIH & MULAI CHANT ✦</bold></gold>",
                "<yellow>Aktifkan senjata terpilih & mulai chant</yellow>"
        ));
        inv.setItem(SLOT_NEXT, buildNavButton(
                Material.ARROW,
                plugin.getConfig().getInt("weapon-selection.scroll-right-cmd", 0),
                "<#68A5E0><bold>Geser Kanan ▶</bold></#68A5E0>",
                "<gray>Klik untuk melihat senjata berikutnya</gray>"
        ));

        if (createNewInv) {
            player.openInventory(inv);
        } else {
            player.getOpenInventory().getTopInventory().setContents(inv.getContents());
        }
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.7f, 1.25f);
    }

    private ItemStack buildNavButton(Material mat, int cmd, String title, String subtitle) {
        ItemStack stack = new ItemStack(mat);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(mm.deserialize(title));
            if (cmd > 0) {
                meta.setCustomModelData(cmd);
            }
            meta.lore(List.of(mm.deserialize(subtitle)));
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack buildOptionCardItem(WeaponOption opt, boolean selectedCenter, int pos, int total) {
        boolean matchWeaponAppearance = plugin.getConfig().getBoolean("weapon-selection.match-weapon-appearance", true);
        boolean appendInfoToLore = plugin.getConfig().getBoolean("weapon-selection.append-info-to-lore", true);
        boolean overrideNameWhenConfigured = plugin.getConfig().getBoolean("weapon-selection.override-display-name", false);
        List<Integer> preferredCmds = plugin.getConfig().getIntegerList("weapon-swap.preferred-custom-model-data");

        ItemStack icon = new ItemStack(opt.iconMaterial);
        try {
            ItemStack built = bridge.createSummonedWeaponForSpec(
                    opt.summonSpec, opt.iconMaterial, opt.customModelData, opt.label, preferredCmds
            );

            boolean hasRealItem = (built != null && built.getType() != Material.AIR);
            icon = hasRealItem ? built.clone() : new ItemStack(opt.iconMaterial);

            if (!hasRealItem || !matchWeaponAppearance) {
                ItemStack customIcon = new ItemStack(opt.iconMaterial);
                ItemMeta customMeta = customIcon.getItemMeta();
                if (customMeta != null && opt.customModelData > 0) {
                    customMeta.setCustomModelData(opt.customModelData);
                }
                customIcon.setItemMeta(customMeta);
                icon = customIcon;
            }

            ItemMeta meta = icon.getItemMeta();
            if (meta != null) {
                if (!hasRealItem || overrideNameWhenConfigured || !meta.hasDisplayName()) {
                    if (opt.label != null && !opt.label.isBlank()) {
                        meta.displayName(mm.deserialize(opt.label));
                    }
                }
                if (appendInfoToLore) {
                    List<Component> lore = meta.hasLore() && meta.lore() != null
                            ? new ArrayList<>(Objects.requireNonNull(meta.lore()))
                            : new ArrayList<>();
                    String skillText = (opt.mythicSkill == null || opt.mythicSkill.isBlank()) ? "Basic Attack" : opt.mythicSkill;
                    lore.add(Component.empty());
                    lore.add(mm.deserialize("<dark_gray>──────────────────────</dark_gray>"));
                    lore.add(mm.deserialize("<gray>Slot: <white>" + pos + "/" + total + "</white> | Skill: <gold>" + skillText + "</gold></gray>"));
                    if (selectedCenter) {
                        lore.add(mm.deserialize("<green>▶ TERPILIH — Klik kartu ini atau tombol tengah untuk Chant!</green>"));
                    } else {
                        lore.add(mm.deserialize("<aqua>Klik untuk menggeser ke senjata ini</aqua>"));
                    }
                    meta.lore(lore);
                }
                icon.setItemMeta(meta);
            }
        } catch (Exception ex) {
            plugin.getLogger().warning("[WeaponGUI] Gagal membuat kartu untuk " + opt.id + ": " + ex.getMessage());
        }
        return icon;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        UUID uuid = player.getUniqueId();
        List<WeaponOption> options = playerOptions.get(uuid);
        if (options == null || options.isEmpty()) return;
        if (event.getView().getTopInventory() != event.getInventory()) return;

        event.setCancelled(true);
        int raw = event.getRawSlot();
        int currentIdx = Math.floorMod(playerIndex.getOrDefault(uuid, 0), options.size());

        if (raw == SLOT_PREV) {
            playerIndex.put(uuid, Math.floorMod(currentIdx - 1, options.size()));
            renderCarousel(player, false);
            return;
        }
        if (raw == SLOT_NEXT) {
            playerIndex.put(uuid, Math.floorMod(currentIdx + 1, options.size()));
            renderCarousel(player, false);
            return;
        }
        if (raw == SLOT_LEFT_PREVIEW) {
            playerIndex.put(uuid, Math.floorMod(currentIdx - 1, options.size()));
            renderCarousel(player, false);
            return;
        }
        if (raw == SLOT_RIGHT_PREVIEW) {
            playerIndex.put(uuid, Math.floorMod(currentIdx + 1, options.size()));
            renderCarousel(player, false);
            return;
        }

        if (raw == SLOT_CENTER_FEATURE || raw == SLOT_CONFIRM) {
            WeaponOption chosen = options.get(currentIdx);
            confirmSelection(player, chosen);
        }
    }

    private void confirmSelection(Player player, WeaponOption chosen) {
        UUID uuid = player.getUniqueId();
        selectedChoice.put(uuid, chosen);
        playerOptions.remove(uuid);
        playerIndex.remove(uuid);
        player.closeInventory();

        executor.setPlayerWeaponOverride(uuid, chosen.summonSpec, chosen.mythicSkill);
        executor.castSolsticeMuzzle(
                player,
                plugin.getConfig().getDouble("skill.base-damage", plugin.getConfig().getDouble("Skill.base-damage", 18.0)),
                plugin.getConfig().getDouble("skill.radius", plugin.getConfig().getDouble("Skill.radius", 4.5)),
                plugin.getConfig().getInt("skill.field-duration-ticks", plugin.getConfig().getInt("Skill.field-duration-ticks", 90))
        );
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player player) {
            playerOptions.remove(player.getUniqueId());
            playerIndex.remove(player.getUniqueId());
        }
    }
}
