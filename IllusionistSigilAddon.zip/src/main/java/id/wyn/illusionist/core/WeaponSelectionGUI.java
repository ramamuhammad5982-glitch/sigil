package id.wyn.illusionist.core;

import id.wyn.illusionist.IllusionistSigilAddon;
import id.wyn.illusionist.hook.PluginBridgeManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class WeaponSelectionGUI implements Listener {

    private final IllusionistSigilAddon plugin;
    private final PluginBridgeManager bridge;
    private final SolsticeMuzzleExecutor executor;
    private final MiniMessage mm = MiniMessage.miniMessage();

    private final Map<UUID, List<WeaponOption>> openMenus = new ConcurrentHashMap<>();
    private final Map<UUID, WeaponOption> selectedChoice = new ConcurrentHashMap<>();

    public static final class WeaponOption {
        public final String id;
        public final String label;
        public final String summonSpec;
        public final String mythicSkill;
        public final Material iconMaterial;
        public final int customModelData;

        public WeaponOption(String id, String label, String summonSpec, String mythicSkill, Material iconMaterial, int customModelData) {
            this.id = id;
            this.label = label;
            this.summonSpec = summonSpec;
            this.mythicSkill = mythicSkill;
            this.iconMaterial = iconMaterial;
            this.customModelData = customModelData;
        }
    }

    public WeaponSelectionGUI(IllusionistSigilAddon plugin, PluginBridgeManager bridge, SolsticeMuzzleExecutor executor) {
        this.plugin = plugin;
        this.bridge = bridge;
        this.executor = executor;
    }

    public List<WeaponOption> getConfiguredOptions() {
        List<WeaponOption> out = new ArrayList<>();
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("weapon-selection.options");
        if (sec != null) {
            for (String key : sec.getKeys(false)) {
                ConfigurationSection itemSec = sec.getConfigurationSection(key);
                if (itemSec == null) continue;
                String label = itemSec.getString("name", key);
                String summonSpec = itemSec.getString("summon-item", "AUTO");
                String skill = itemSec.getString("mythic-skill", "");
                String matName = itemSec.getString("icon-material", "DIAMOND_SWORD").toUpperCase(Locale.ROOT);
                Material mat = Material.matchMaterial(matName);
                if (mat == null) mat = Material.DIAMOND_SWORD;
                int cmd = itemSec.getInt("custom-model-data", 0);
                out.add(new WeaponOption(key, label, summonSpec, skill, mat, cmd));
            }
        }
        if (out.isEmpty()) {
            out.add(new WeaponOption("doomblaster", "<gradient:#FF5555:#FFD06C>Doomblaster</gradient>",
                    "MMOITEMS:SWORD:AWAKENED_GUNSLINGER_DOOMBLASTER", "", Material.STONE_SWORD, 2095));
            out.add(new WeaponOption("spirit_greataxe", "<gradient:#51d54e:#80f7fd>Spirit GreatAxe</gradient>",
                    "MMOITEMS:SWORD:SPIRITRPG", "", Material.STICK, 88655));
            out.add(new WeaponOption("infernal_dominion", "<gradient:#7A0C0C:#B22222>Infernal Dominion</gradient>",
                    "MMOITEMS:SWORD:INFERNAL_DOMINION", "", Material.STICK, 100));
            out.add(new WeaponOption("kurayami_eclipse", "<gradient:#81adff:#a4f9ff>Kurayami Eclipse</gradient>",
                    "MMOITEMS:SWORD:KURAYAMI", "", Material.STICK, 1347));
            out.add(new WeaponOption("gauntlet_of_times", "<gradient:#E3DB46:#ECEf79>Gauntlet Of Times</gradient>",
                    "MMOITEMS:SWORD:GAUNTLET_OF_TIMES", "", Material.DIAMOND_SWORD, 70111));
        }
        return out;
    }

    public WeaponOption getSelectedOption(Player player) {
        return selectedChoice.get(player.getUniqueId());
    }

    public void openSelectionMenu(Player player) {
        List<WeaponOption> options = getConfiguredOptions();
        String titleRaw = plugin.getConfig().getString("weapon-selection.menu-title", "<#F5C542>Pilih Senjata Sigil</#F5C542>");
        boolean matchWeaponAppearance = plugin.getConfig().getBoolean("weapon-selection.match-weapon-appearance", true);
        boolean appendInfoToLore = plugin.getConfig().getBoolean("weapon-selection.append-info-to-lore", true);
        boolean overrideNameWhenConfigured = plugin.getConfig().getBoolean("weapon-selection.override-display-name", false);

        int size = Math.max(9, Math.min(54, ((options.size() + 8) / 9) * 9));
        Inventory inv = Bukkit.createInventory(null, size, mm.deserialize(titleRaw));

        List<Integer> preferredCmds = plugin.getConfig().getIntegerList("weapon-swap.preferred-custom-model-data");

        int slot = 0;
        for (WeaponOption opt : options) {
            if (slot >= size) break;
            ItemStack built = bridge.createSummonedWeaponForSpec(
                    opt.summonSpec, opt.iconMaterial, opt.customModelData, opt.label, preferredCmds
            );

            boolean hasRealItem = (built != null && built.getType() != Material.AIR);
            ItemStack icon = hasRealItem ? built.clone() : new ItemStack(opt.iconMaterial);

            if (!hasRealItem || !matchWeaponAppearance) {
                ItemStack customIcon = new ItemStack(opt.iconMaterial);
                ItemMeta customMeta = customIcon.getItemMeta();
                if (customMeta != null && opt.customModelData > 0) {
                    customMeta.setCustomModelData(opt.customModelData);
                }
                customIcon.setItemMeta(customMeta);
                icon = customIcon;
            }

            ItemMeta meta = icon.getItemMeta();
            if (meta != null) {
                if (!hasRealItem || overrideNameWhenConfigured || !meta.hasDisplayName()) {
                    if (opt.label != null && !opt.label.isBlank()) {
                        meta.displayName(mm.deserialize(opt.label));
                    }
                }
                if (appendInfoToLore) {
                    List<Component> lore = meta.hasLore() && meta.lore() != null
                            ? new ArrayList<>(Objects.requireNonNull(meta.lore()))
                            : new ArrayList<>();
                    String skillText = (opt.mythicSkill == null || opt.mythicSkill.isBlank()) ? "Basic Attack" : opt.mythicSkill;
                    lore.add(Component.empty());
                    lore.add(mm.deserialize("<dark_gray>──────────────────────</dark_gray>"));
                    lore.add(mm.deserialize("<gray>Mode: <gold>" + skillText + "</gold></gray>"));
                    lore.add(mm.deserialize("<yellow>Klik untuk memilih & memulai chant!</yellow>"));
                    meta.lore(lore);
                }
                icon.setItemMeta(meta);
            }
            inv.setItem(slot++, icon);
        }

        openMenus.put(player.getUniqueId(), options);
        player.openInventory(inv);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        List<WeaponOption> options = openMenus.get(player.getUniqueId());
        if (options == null) return;
        if (event.getView().getTopInventory() != event.getInventory()) return;

        event.setCancelled(true);
        int raw = event.getRawSlot();
        if (raw < 0 || raw >= options.size()) return;

        WeaponOption chosen = options.get(raw);
        selectedChoice.put(player.getUniqueId(), chosen);
        openMenus.remove(player.getUniqueId());
        player.closeInventory();

        executor.setPlayerWeaponOverride(player.getUniqueId(), chosen.summonSpec, chosen.mythicSkill);

        executor.castSolsticeMuzzle(
                player,
                plugin.getConfig().getDouble("skill.base-damage", plugin.getConfig().getDouble("Skill.base-damage", 18.0)),
                plugin.getConfig().getDouble("skill.radius", plugin.getConfig().getDouble("Skill.radius", 4.5)),
                plugin.getConfig().getInt("skill.field-duration-ticks", plugin.getConfig().getInt("Skill.field-duration-ticks", 90))
        );
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player player) {
            openMenus.remove(player.getUniqueId());
        }
    }
}
